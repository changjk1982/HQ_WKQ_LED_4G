/*
********************************************************************************
** @file    : bsp_tim2_puhuo.c
** @author  : 
** @version : 
** @date    : 
** @brief   :
********************************************************************************
*/

/*==============================================================================
** Includes
==============================================================================*/
#include "bsp_tim2_puhuo.h"

/*==============================================================================
** Private typedef
==============================================================================*/

/*==============================================================================
** Private macro
==============================================================================*/


/*==============================================================================
** Private define
==============================================================================*/

/*==============================================================================
** Private variables
==============================================================================*/
uint16_t TimerPeriod = 0;
uint16_t Channel1Pulse = 0;

/*==============================================================================
** Private function prototypes
==============================================================================*/


/************************����GPIO**********************************************/
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOC, ENABLE );	
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOD, ENABLE );	
		
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOD,GPIO_Pin_3);
	GPIO_ResetBits(GPIOD,GPIO_Pin_6);
		
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
/************************����GPIO�ĸ��ù���************************************/
    GPIO_PinAFConfig(GPIOC,GPIO_PinSource6,GPIO_AF_3);//TIM1_CH1
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_1;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
/************************����GPIO�ĸ��ù���************************************/
    GPIO_PinAFConfig(GPIOC,GPIO_PinSource5,GPIO_AF_4);//TIM2_CH1
}
/*************************����TIMER*********************************************/
void TIM_Config(void)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_ICInitTypeDef  TIM_ICInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
	
	
	RCC_APBPeriph2ClockCmd(RCC_APBPeriph2_TIM1, ENABLE );
	
/*************************Ƶ������Ϊ100KHZ****************************************/
    TimerPeriod = (SystemCoreClock / 1000 ) - 1;

/*************************ʱ������**********************************************/
    TIM_TimeBaseStructure.TIM_Prescaler =1000;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = TimerPeriod;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;

    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

			
/*************************����TIM1 Channel1���벶��*****************************/
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;
    TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising; 
    TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
    TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
    TIM_ICInitStructure.TIM_ICFilter = 0x0;
    TIM_ICInit(TIM1, &TIM_ICInitStructure);
		
/*************************����TIM1 Channel1 PWM1���벶��************************/
	TIM_PWMIConfig(TIM1,&TIM_ICInitStructure);
		
	TIM_SelectInputTrigger(TIM1,TIM_TS_TI1FP1);
	TIM_SelectSlaveMode(TIM1,TIM_SlaveMode_Reset);
		
/*************************ʹ��TIM1 CC1�ж�����*********************************/
    TIM_ITConfig(TIM1, TIM_IT_CC1, ENABLE);
    TIM_ClearITPendingBit(TIM1, TIM_IT_CC1);
/*************************ʹ��TIM1 ������***************************************/
    TIM_Cmd(TIM1, ENABLE);

/*************************����NVIC TIM1ȫ���ж�********************************/
    NVIC_InitStructure.NVIC_IRQChannel = TIM1_CC_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
/************************����TIM2**********************************************/
void TIM2_config(void)//�������
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    
	RCC_APBPeriph1ClockCmd(RCC_APBPeriph1_TIM2, ENABLE );
	
    /* Time Base configuration */
    TIM_TimeBaseStructure.TIM_Prescaler = 1000-1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = 480-1;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;

    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    /* Channel 1, 2,3 and 4 Configuration in PWM mode */
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 48;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;

    TIM_OC1Init(TIM2, &TIM_OCInitStructure);

    /* TIM1 counter enable */
    TIM_Cmd(TIM2, ENABLE);

    

}	


/*********************************** EOF **************************************/



