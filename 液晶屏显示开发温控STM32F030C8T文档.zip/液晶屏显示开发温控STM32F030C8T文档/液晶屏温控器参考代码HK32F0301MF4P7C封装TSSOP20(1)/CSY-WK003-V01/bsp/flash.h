#ifndef _FLASH_H
#define _FLASH_H
 
#ifndef __FLASH_C_
#define FLASH_INTERFACE extern
#else
#define FLASH_INTERFACE
#endif/*__FLASH_C_*/
#include "hk32f0301mxxc_flash.h"

typedef union 
{
    uint32_t u32Data;
    uint8_t u8Data[4];
}DATA_BUFF;

#define FLASH_ADDRESS            	0x08003f00
#define FLASH_SIZE								0x5000
#define PAGE_SIZE                 0x00000080
#define FLASH_OP_ADDR							0x08003f00 
void Flash_Erase(uint32_t u32FlashAddress);
FLASH_INTERFACE void Flash_WriteData(void);
FLASH_INTERFACE void Flash_ReadData(void);
void Flash_Write(uint32_t u32FlashAddress,uint8_t *u8pFlashData,uint16_t u16FlashSize);
void Flash_OB_Write(void);


#endif/*_FLASH_H*/
