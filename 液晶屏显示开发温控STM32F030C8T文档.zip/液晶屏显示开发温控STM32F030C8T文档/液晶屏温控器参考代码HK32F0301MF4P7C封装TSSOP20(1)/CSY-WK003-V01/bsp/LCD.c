#include "LCD.h"
#define TOTAL_SEGS	21
static void UpdateLCDData(void);
unsigned char bUpdateLCD=0;

void LCDInit(void)
{
    Ht1621_Init();
}

uint8_t	gLCDDisplayRAMData[TOTAL_SEGS] = { 0 };// LCD��ʾ����
uint8_t bTempNoramlDisplay=false;
static const uint8_t NUM_DATA[20]={ 0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x00,0x40,0X38,0X76};
// �������ʾ����
void DigtalDisplay(uint8_t dig, uint8_t data)
{
    uint8_t var;
    switch (dig)
    {
			case 0:
					var = 8;
				break;
			case 1:
					var = 10;
				break;
			case 2:
					var = 12;
					break;
			case 3://start
					var = 14;
					break;
			case 4:
					var = 16;
					break;
			case 5:
					var = 18;
					break;
			case 6:   //stop
					var = 4;
					break;
			case 7:
					var = 2;
					break;
			case 8:
					var = 0;
					break;
    }
		if(dig<6)
		{
				gLCDDisplayRAMData[var+1] |= SMG_LED_BIT(data, LED_A)<<0;
				gLCDDisplayRAMData[var+1] |= SMG_LED_BIT(data, LED_B)<<1;
				gLCDDisplayRAMData[var+1] |= SMG_LED_BIT(data, LED_C)<<2;
				gLCDDisplayRAMData[var+1] |= SMG_LED_BIT(data, LED_D)<<3;
			
				gLCDDisplayRAMData[var] |= SMG_LED_BIT(data, LED_E) << 3;
				gLCDDisplayRAMData[var] |= SMG_LED_BIT(data, LED_F) << 1;
				gLCDDisplayRAMData[var] |= SMG_LED_BIT(data, LED_G) <<2;
		}
		else
		{
				gLCDDisplayRAMData[var] |= SMG_LED_BIT(data, LED_A)<<3;
				gLCDDisplayRAMData[var] |= SMG_LED_BIT(data, LED_B)<<2;
				gLCDDisplayRAMData[var] |= SMG_LED_BIT(data, LED_C)<<1;
				gLCDDisplayRAMData[var] |= SMG_LED_BIT(data, LED_D)<<0;
				
				gLCDDisplayRAMData[var+1] |= SMG_LED_BIT(data, LED_E) <<0;
				gLCDDisplayRAMData[var+1] |= SMG_LED_BIT(data, LED_F) <<2;
				gLCDDisplayRAMData[var+1] |= SMG_LED_BIT(data, LED_G) <<1;					  
		}
}




void icon_display(void)
{
		if(display_data[7]&STOPTEMP_DOT_ICON)
				gLCDDisplayRAMData[1]|=0x8;
		if(display_data[4]&STARTTEMP_DOT_ICON)
				gLCDDisplayRAMData[20]|=0x8;
		if(display_data[1]&REALTEMP_DOT_ICON)
				gLCDDisplayRAMData[6]|=0x4;
		//
		if(display_data[9]&REALTEMP_ICON)
			gLCDDisplayRAMData[8]|=0x01;
		if(display_data[9]&RUNNING_ICON)
			gLCDDisplayRAMData[10]|=0x01;
		if(display_data[9]&CAL_ICON)
			gLCDDisplayRAMData[12]|=0x01;
		if(display_data[9]&CYCLE_RUNNING_ICON)
			gLCDDisplayRAMData[7]|=0x02;
		if(display_data[9]&TIMING_ICON)
			gLCDDisplayRAMData[7]|=0x01;
		if(display_data[9]&TIMING_ON_ICON)
			gLCDDisplayRAMData[6]|=0x02;
		if(display_data[9]&TIMING_OFF_ICON)
			gLCDDisplayRAMData[6]|=0x01;
		if(display_data[10]&START_ICON)
			gLCDDisplayRAMData[14]|=0x01;	
		if(display_data[10]&START_TEMP_ICON)
			gLCDDisplayRAMData[16]|=0x01;
		if(display_data[10]&START_TIME_ICON)
			gLCDDisplayRAMData[18]|=0x01;
		if(display_data[10]&START_MIN_ICON)
			gLCDDisplayRAMData[20]|=0x01;
		if(display_data[10]&STOP_ICON)
			gLCDDisplayRAMData[5]|=0x08;
		if(display_data[10]&STOP_TEMP_ICON)
			gLCDDisplayRAMData[3]|=0x08;
		if(display_data[10]&STOP_TIME_ICON)
			gLCDDisplayRAMData[20]|=0x04;
		if(display_data[10]&STOP_MIN_ICON)
			gLCDDisplayRAMData[20]|=0x02;
}
static void UpdateLCDData(void)
{
    uint8_t i = 0;
    memset(gLCDDisplayRAMData, 0x00, TOTAL_SEGS);
		for(i=0;i<9;i++)
			DigtalDisplay(i,display_data[i]&0X7F);
		icon_display();
		
}

void lcd_display(void)
{
		uint8_t seg;
		UpdateLCDData();
		for (seg = 0; seg < TOTAL_SEGS; seg++)
		{
				Ht1621WrOneData(((32-TOTAL_SEGS)+seg),gLCDDisplayRAMData[seg]);
		}	
}

void LCDDisplayProcess(void)
{
    uint8_t seg;
//    static uint32_t sTickTime = 0, sTickTime1;
    if (bUpdateLCD)
    {
        bUpdateLCD= false;
        UpdateLCDData();
        for (seg = 0; seg < TOTAL_SEGS; seg++)
        {
            Ht1621WrOneData(((32-TOTAL_SEGS)+seg), gLCDDisplayRAMData[seg]);
        }
    }


}

