/*
********************************************************************************
** @file    : bsp_gpio_led.h
** @author  : 
** @version : 
** @date    : 
** @brief   :            
********************************************************************************
*/ 
  
#ifndef __BSP_GPIO_LED_H
#define __BSP_GPIO_LED_H

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================
** Includes
==============================================================================*/
#include "hk32f0301mxxc.h"

/*==============================================================================
** Exported types
==============================================================================*/
typedef enum
{
  LOW = 0,
  HIGH = 1
} Gpio_State;

typedef enum 
{
	LED1 = 0,
  LED2,
	LED3, 
} Gpio_TypeDef;

/*==============================================================================
** Exported constants
==============================================================================*/

/*==============================================================================
** Exported macros
==============================================================================*/

/*==============================================================================
** Exported definitions
==============================================================================*/
#define GPIOn                            3

#define GPIO_LED1_PIN                    GPIO_Pin_1
#define GPIO_LED1_PORT                   GPIOD
#define GPIO_LED1_CLK                    RCC_AHBPeriph_GPIOD
#define GPIO_LED1_MODE                   GPIO_Mode_OUT
#define GPIO_LED1_SPEED                  GPIO_Speed_Level_2
#define GPIO_LED1_OTYPE                  GPIO_OType_PP
#define GPIO_LED1_PUPD                   GPIO_PuPd_NOPULL
#define GPIO_LED1_SCHMIT                 GPIO_Schmit_Enable
#define GPIO_LED1_INITSTATE              HIGH
  
#define GPIO_LED2_PIN                    GPIO_Pin_7
#define GPIO_LED2_PORT                   GPIOC
#define GPIO_LED2_CLK                    RCC_AHBPeriph_GPIOC
#define GPIO_LED2_MODE                   GPIO_Mode_OUT
#define GPIO_LED2_SPEED                  GPIO_Speed_Level_2
#define GPIO_LED2_OTYPE                  GPIO_OType_PP
#define GPIO_LED2_PUPD                   GPIO_PuPd_NOPULL
#define GPIO_LED2_SCHMIT                 GPIO_Schmit_Enable
#define GPIO_LED2_INITSTATE              HIGH

#define GPIO_LED3_PIN                    GPIO_Pin_2
#define GPIO_LED3_PORT                   GPIOA
#define GPIO_LED3_CLK                    RCC_AHBPeriph_GPIOA
#define GPIO_LED3_MODE                   GPIO_Mode_OUT
#define GPIO_LED3_SPEED                  GPIO_Speed_Level_2
#define GPIO_LED3_OTYPE                  GPIO_OType_PP
#define GPIO_LED3_PUPD                   GPIO_PuPd_NOPULL
#define GPIO_LED3_SCHMIT                 GPIO_Schmit_Enable
#define GPIO_LED3_INITSTATE              HIGH

/*==============================================================================
** Exported functions
==============================================================================*/
void BSP_GPIO_Init(Gpio_TypeDef Gpio);
void BSP_GPIO_SetHigh(Gpio_TypeDef Gpio);
void BSP_GPIO_SetLow(Gpio_TypeDef Gpio);
void BSP_GPIO_Toggle(Gpio_TypeDef Gpio);

void BSP_LED_Init(Gpio_TypeDef Led);
void BSP_LED_TurnOn(Gpio_TypeDef Led);
void BSP_LED_TurnOff(Gpio_TypeDef Led);
void BSP_LED_Toggle(Gpio_TypeDef Led);


#ifdef __cplusplus
}
#endif

#endif /* __BSP_GPIO_LED_H */

/*********************************** EOF **************************************/
