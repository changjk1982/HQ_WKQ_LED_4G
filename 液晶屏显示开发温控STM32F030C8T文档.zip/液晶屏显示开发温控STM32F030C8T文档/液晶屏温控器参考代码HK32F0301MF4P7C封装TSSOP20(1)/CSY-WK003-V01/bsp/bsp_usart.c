/*
********************************************************************************
** @file    : bsp_usart.c
** @author  : 
** @version : 
** @date    : 
** @brief   :
********************************************************************************
*/

/*==============================================================================
** Includes
==============================================================================*/
#include "bsp_usart.h"

/*==============================================================================
** Private typedef
==============================================================================*/

/*==============================================================================
** Private macro
==============================================================================*/
#define USART1_IRQ_ENABLE             0

/*==============================================================================
** Private define
==============================================================================*/


/*==============================================================================
** Private variables
==============================================================================*/
UART_TypeDef* COM_UART[COMn]            = {COM1_UART,COM2_UART};
const uint32_t COM_UART_CLK[COMn]       = {COM1_CLK,COM2_CLK};

GPIO_TypeDef* COM_TX_PORT[COMn]         = {COM1_TX_GPIO_PORT,COM2_TX_GPIO_PORT};
const uint16_t COM_TX_PIN[COMn]         = {COM1_TX_PIN,COM2_TX_PIN};
const uint32_t COM_TX_PORT_CLK[COMn]    = {COM1_TX_GPIO_CLK,COM2_TX_GPIO_CLK};
const uint8_t COM_TX_PIN_SOURCE[COMn]   = {COM1_TX_SOURCE,COM2_TX_SOURCE};
const uint8_t COM_TX_AF[COMn]           = {COM1_TX_AF,COM2_TX_AF};

GPIO_TypeDef* COM_RX_PORT[COMn]         = {COM1_RX_GPIO_PORT,COM2_RX_GPIO_PORT};
const uint16_t COM_RX_PIN[COMn]         = {COM1_RX_PIN,COM2_RX_PIN}; 
const uint32_t COM_RX_PORT_CLK[COMn]    = {COM1_RX_GPIO_CLK,COM2_RX_GPIO_CLK};
const uint8_t COM_RX_PIN_SOURCE[COMn]   = {COM1_RX_SOURCE,COM2_RX_SOURCE}; 
const uint8_t COM_RX_AF[COMn]           = {COM1_RX_AF,COM2_RX_AF};

unsigned char uart1_rx_buf[UART1_RX_BUFLEN];
unsigned char uart1_tx_buf[UART1_TX_BUFLEN];

unsigned char uart2_rx_buf[UART1_RX_BUFLEN];
unsigned char uart2_tx_buf[UART1_TX_BUFLEN];

unsigned char uart1_tx_cnt=0;
unsigned char uart1_tx_len=0;
unsigned char uart1_tx_complete=1;

unsigned char uart1_rx_cnt=0;
unsigned char uart1_rx_complete=0;

unsigned char uart2_tx_cnt=0;
unsigned char uart2_tx_len=0;
unsigned char uart2_tx_complete=1;

unsigned char uart2_rx_cnt=0;
unsigned char uart2_rx_complete=0;

/*==============================================================================
** Private function prototypes
==============================================================================*/
static void BSP_UART_ComInit(Com_TypeDef Com, UART_InitTypeDef* USART_InitStruct);


/******************************************************************************/
/*                          Function Implementation                           */
/******************************************************************************/
/*******************************************************************************
** @function : BSP_USART_Config
** @brief    : Configures USART  
** @param    : Com - Specifies the COM port to be configured 
**             Baud - Specifies the baud rate to the USART
** @retval   : None
*******************************************************************************/
void BSP_UART_Config(Com_TypeDef Com, uint32_t Baud)
{ 
  UART_InitTypeDef UART_InitStructure;
  
  UART_InitStructure.UART_BaudRate = Baud;
  UART_InitStructure.UART_WordLength = UART_WordLength_8b;
  UART_InitStructure.UART_StopBits = UART_StopBits_1;
  UART_InitStructure.UART_Parity = UART_Parity_No;
  UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;  
  BSP_UART_ComInit(Com, &UART_InitStructure);
	
}

void USART_NVICConfig(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
		
	NVIC_InitStructure.NVIC_IRQChannel = COM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd  = ENABLE;
	NVIC_Init(&NVIC_InitStructure);	

	UART_ITConfig(UART2,UART_IT_RXNE,ENABLE);	
	UART_ITConfig(UART2,UART_IT_IDLE,ENABLE);
	//UART_ITConfig(UART2,UART_IT_TXE,ENABLE);	
	//UART_ITConfig(UART2,UART_IT_TC,ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = COM1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd  = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	UART_ITConfig(UART1,UART_IT_RXNE,ENABLE);	
	UART_ITConfig(UART1,UART_IT_IDLE,ENABLE);
	//UART_ITConfig(UART1,UART_IT_TXE,ENABLE);	
	//UART_ITConfig(UART1,UART_IT_TC,ENABLE);
}

/*******************************************************************************
** @function : BSP_USART_ComInit
** @brief    : Configures COM port  
** @param    : Com - Specifies the COM port to be configured
**             USART_InitStruct - Pointer to a USART_InitTypeDef structure that
**                                contains the configuration information for  
**                                the specified USART peripheral
** @retval   : None
*******************************************************************************/
static void BSP_UART_ComInit(Com_TypeDef Com, UART_InitTypeDef* UART_InitStruct)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIO clock */
	//	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD|RCC_AHBPeriph_GPIOA|RCC_AHBPeriph_GPIOB|RCC_AHBPeriph_GPIOC, ENABLE);
    RCC_AHBPeriphClockCmd(COM_TX_PORT_CLK[Com] | COM_RX_PORT_CLK[Com], ENABLE);
    /* Enable USART clock */
		if(Com==COM1)
		{
			RCC_APBPeriph2ClockCmd(COM_UART_CLK[Com], ENABLE); 
			GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_1;
		}
		else if(Com==COM2)
		{
			RCC_APBPeriph1ClockCmd(RCC_APBPeriph1_UART2,ENABLE);
			GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_1;
		}
    /* Configure USART Tx as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = COM_TX_PIN[Com];
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(COM_TX_PORT[Com], &GPIO_InitStructure);
    
	//	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;	
    /* Configure USART Rx as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = COM_RX_PIN[Com];
    GPIO_Init(COM_RX_PORT[Com], &GPIO_InitStructure);
    
    /* Connect PXx to USARTx_Tx */
    GPIO_PinAFConfig(COM_TX_PORT[Com], COM_TX_PIN_SOURCE[Com], COM_TX_AF[Com]);
    /* Connect PXx to USARTx_Rx */
    GPIO_PinAFConfig(COM_RX_PORT[Com], COM_RX_PIN_SOURCE[Com], COM_RX_AF[Com]);
    /* USART configuration */
    UART_Init(COM_UART[Com], UART_InitStruct);
	
	#if USART1_IRQ_ENABLE
	/* Enable USART receive interrupt */
	UART_ITConfig(COM_UART[Com], UART_IT_RXNE, ENABLE);
	
	/* Enable USART Idle interrupt */
	UART_ITConfig(COM_UART[Com], UART_IT_IDLE, ENABLE);
	
	/* Set USART1 Interrupt Priority */
	NVIC_SetPriority(COM1_IRQn, 3);
	
	/* Enable USART1 interrupt */
	NVIC_EnableIRQ(COM1_IRQn);
	#endif
    //������õ�TX��RX����ʵ��Ӳ����Ҫ����,������������
//	USART_SWAPPinCmd(USART1, ENABLE);    // ����TX��RX����
  /* Enable USART */
  UART_Cmd(COM_UART[Com], ENABLE);
}


/*******************************************************************************
** @function : BSP_USART_SendByte
** @brief    : Send one byte data 
** @param    : USARTx - Specifies the USART port
**             data - Data to be sent
** @retval   : None
*******************************************************************************/
void BSP_UART_SendByte(UART_TypeDef* UARTx, uint8_t Data)
{
	/* Loop until transmit data register is empty */
   while (UART_GetFlagStatus(UARTx, UART_FLAG_TXE) == RESET)
   {}	
		/* Transmit a byte data to to USART */
			UART_SendData(UARTx, Data);
}	


/*******************************************************************************
** @function : BSP_USART_SendString
** @brief    : Send string from USART 
** @param    : USARTx - Specifies the USART port
**             str - pointer string to be sent
** @retval   : None
*******************************************************************************/
void BSP_UART_SendString(UART_TypeDef* UARTx, char* Str)
{
 // unsigned char i=0;
	
//	/* Loop until transmit completely */
//		while(UART_GetFlagStatus(UARTx, UART_FLAG_TC) == RESET)
//		{}	
//		BSP_UART_SendByte(UARTx, '\r');

	do
	{
		BSP_UART_SendByte(UARTx, *Str);
		Str++;
	} while (*(Str) != '\0');
	
	/* Loop until transmit completely */
	while(UART_GetFlagStatus(UARTx, UART_FLAG_TC) == RESET)
	{}
		
		
//		if(UARTx==UART1)
//		{
////			while(UART_GetFlagStatus(UARTx, UART_FLAG_TC) == RESET)
////			{}
//			while(uart1_tx_complete==0){};
//			while(UART_GetFlagStatus(UARTx, UART_FLAG_TC) == RESET)
//			{}	
////				BSP_UART_SendByte(UARTx, *(Str));	
////			UART_ITConfig(UART1,UART_IT_TXE,ENABLE);	
////				
////						
////									
//			do
//			{
//				
//				uart1_tx_buf[uart1_tx_cnt]=*(Str);
//				Str++;	
//				uart1_tx_cnt++;
//			} while (*(Str) != '\0');
//			uart1_tx_len=uart1_tx_cnt;	
//			uart1_tx_complete=0;
//			UART_ITConfig(UART1,UART_IT_TXE,ENABLE);
//		}
//		else if(UARTx==UART2)
//		{
//			while(uart2_tx_complete==0){};									
//			do
//			{
//				
//				uart2_tx_buf[uart2_tx_cnt]=*(Str);
//				Str++;	
//				uart2_tx_cnt++;
//			} while (*(Str) != '\0');
//			uart2_tx_len=uart2_tx_cnt;	
//			uart2_tx_complete=0;
//			UART_ITConfig(UART2,UART_IT_TXE,ENABLE);			
//		}
	 
}


#if 0
/*******************************************************************************
** @function : fputc
** @brief    : Retargets the C library printf function to the USART  
** @param    : None
** @retval   : None
*******************************************************************************/ 
int fputc(int ch, FILE *f)
{
	/* Place your implementation of fputc here */
  /* e.g. write a character to the USART */
  
  /* Loop until transmit data register is empty */
  while (UART_GetFlagStatus(COM_UART[COM1], UART_FLAG_TXE) == RESET)
  {};
	UART_SendData(COM_UART[COM1], (uint8_t)ch);
  return ch;
}
 
/*******************************************************************************
** @function : fgetc
** @brief    : Retargets the C library scanf function to the USART  
** @param    : None
** @retval   : None
*******************************************************************************/ 
int fgetc(FILE *f)
{
	/* Place your implementation of fgetc here */
  /* Loop until receive data register is not empty */
  while (UART_GetFlagStatus(COM_UART[COM1], UART_FLAG_RXNE) == RESET)
  {};
  return (int)UART_ReceiveData(COM_UART[COM1]);
}

#endif
void UART1_IRQHandler()
{
	if(UART_GetITStatus(UART1,UART_IT_RXNE) == SET)
	{
			uart1_rx_buf[uart1_rx_cnt]=UART_ReceiveData(COM_UART[COM1]);
			uart1_rx_cnt++;
	}	
	else if(UART_GetITStatus(UART1,UART_IT_IDLE) == SET)
	{
			UART_ClearITPendingBit(UART1, UART_IT_IDLE);
			uart1_rx_buf[uart1_rx_cnt]='\0';
			uart1_rx_cnt=0;
		  uart1_rx_complete=1;		  //set read complete flag
		  
	}
	else if(UART_GetITStatus(UART1,UART_IT_TXE) == SET)//TX EMPTY
	{
		UART_ClearITPendingBit(UART1, UART_IT_TXE);
		if(uart1_tx_cnt)
		{				
			UART_SendData(UART1, uart1_tx_buf[uart1_tx_len-uart1_tx_cnt]);	
			uart1_tx_cnt-=1;		
		}
		else
		{
			 UART_ITConfig(UART1,UART_IT_TXE,DISABLE);	
			 uart1_tx_complete=1; 
		}
	}	
//	else if(UART_GetITStatus(UART1,UART_IT_TC) == SET)//TX complete
//	{
//		UART_ClearITPendingBit(UART1, UART_IT_TC);
//		if(uart1_tx_cnt==0&&uart1_tx_complete==0)
//		{
//			UART_ITConfig(UART1,UART_IT_TXE,DISABLE);	
//			uart1_tx_complete=1; 
//		}
//	}
	else if(UART_GetITStatus(UART1,UART_IT_FE) == SET)
	{
			UART_ClearITPendingBit(UART1, UART_IT_FE);
			printf("\r\nUART_IT_FE\r\n");
	}
	else if(UART_GetITStatus(UART1,UART_IT_NE) == SET)
	{
		UART_ClearITPendingBit(UART1, UART_IT_NE);
		printf("\r\nUART_IT_NE\r\n");
	}
	else if(UART_GetITStatus(UART1,UART_IT_ORE) == SET)
	{
		UART_ClearITPendingBit(UART1, UART_IT_ORE);
		printf("\r\nUART_IT_ORE\r\n");
	}
	
	else
	{
		printf("\r\nother IT\r\n");
		UART1->ICR=0xffffffff;
	}
		
}

void UART2_IRQHandler()
{
	if(UART_GetITStatus(UART2,UART_IT_RXNE) == SET)
	{
			uart2_rx_buf[uart2_rx_cnt]=UART_ReceiveData(COM_UART[COM2]);
			uart2_rx_cnt++;		
//			if(uart2_rx_buf[uart2_rx_cnt-1]==0x21)
//			{
//				uart2_rx_cnt=0;
//				uart2_rx_complete=1;
//				uart2_rx_buf[uart2_rx_cnt]='\0';
//			}
	}	
	else if(UART_GetITStatus(UART2,UART_IT_IDLE) == SET)
	{
			UART_ClearITPendingBit(UART2, UART_IT_IDLE);
			uart2_rx_buf[uart2_rx_cnt]='\0';
			uart2_rx_cnt=0;
		  uart2_rx_complete=1;		  //set read complete flag
		//  printf("\r\nUART_IT_IDLE\r\n");
//		  if(uart2_tx_cnt==0&&uart2_tx_complete==0)
//			{
////				 UART_ITConfig(UART2,UART_IT_TXE,DISABLE);	
////				 uart2_tx_complete=1; 
//				 GPIO_ResetBits(GPIOD,GPIO_Pin_7);
//			}
	}
	else if(UART_GetITStatus(UART2,UART_IT_TC) == SET)//TX complete
	{
		UART_ClearITPendingBit(UART2, UART_IT_TC);
		if(uart2_tx_cnt==0&&uart2_tx_complete==0)
		{		 
			 uart2_tx_complete=1; 
//			 GPIO_ResetBits(GPIOD,GPIO_Pin_7);
			 UART_ITConfig(UART2,UART_IT_TXE,DISABLE);	
		}printf("\r\nUART2_IT_TC\r\n");
	}
//	else if(UART_GetITStatus(UART2,UART_IT_TXE) == SET)//TX EMPTY
//	{
//		UART_ClearITPendingBit(UART2, UART_IT_TXE);
//		if(uart2_tx_cnt)
//		{	
//			GPIO_SetBits(GPIOD,GPIO_Pin_7);			
//			UART_SendData(UART2, uart2_tx_buf[uart2_tx_len-uart2_tx_cnt]);	
//			uart2_tx_cnt-=1;		
//		}
//		else
//		{
//			 if(uart2_tx_complete)
//			 {
////				 while(UART_GetFlagStatus(UART1, UART_FLAG_TC) == RESET)
////				 {}
////				 UART_ITConfig(UART2,UART_IT_TXE,DISABLE);	
////				 GPIO_ResetBits(GPIOD,GPIO_Pin_7); 
//			 }
//			 else
//			 {
//					uart2_tx_complete=1; 
//			 } 
//		}	
//	}	
	
	else if(UART_GetITStatus(UART2,UART_IT_FE) == SET)
	{
			UART_ClearITPendingBit(UART2, UART_IT_FE);
			printf("\r\nUART2_IT_FE\r\n");
	}
	else if(UART_GetITStatus(UART2,UART_IT_NE) == SET)
	{
		UART_ClearITPendingBit(UART2, UART_IT_NE);
		printf("\r\nUART2_IT_NE\r\n");
	}
	else if(UART_GetITStatus(UART2,UART_IT_ORE) == SET)
	{
		UART_ClearITPendingBit(UART2, UART_IT_ORE);
		printf("\r\nUART2_IT_ORE\r\n");
	}
	
	else
	{
		printf("\r\nuart2nother IT\r\n");
		UART2->ICR=0xffffffff;
	}
		
}
/*********************************** EOF **************************************/



