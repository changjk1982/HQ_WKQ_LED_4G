/**************************************************************************************************
* @file    : flash.c
* @brief   : Main program body. Write data to flash with halfword
**************************************************************************************************/

#define __FLASH_C_
/* -----------------------------Includes ----------------------------------------------------------*/

#include "flash.h"
#include "bsp_usart.h"

 /* -----------------------------start of Static Flash functions -------------------------------------*/
void Flash_Erase(uint32_t u32FlashAddress)
{
    FLASH_Status eStatus = FLASH_COMPLETE;

    FLASH_Unlock();
    eStatus = FLASH_ErasePage(u32FlashAddress);
    FLASH_Lock();

//    if(eStatus == FLASH_COMPLETE)
//    {
//        printf("\r\nFlash Erase ok at:0x%08x",u32FlashAddress);
//    }
//    else
//    {
//        printf("\r\nFlash Erase Failed at:0x%08x",u32FlashAddress);
//    }
} 

void Flash_Write(uint32_t u32FlashAddress,uint8_t *u8pFlashData,uint16_t u16FlashSize)
{
    FLASH_Status eStatus = FLASH_COMPLETE;
    uint8_t i ;
	//  printf("\r\nFlash Program enter");
    FLASH_Unlock();
    for ( i = 0; i < u16FlashSize; i+=4)
    {
        eStatus = FLASH_ProgramWord(u32FlashAddress + i,(u8pFlashData[i+3]<<24)+(u8pFlashData[i+2]<<16)+(u8pFlashData[i+1]<<8)+u8pFlashData[i]); 
        if(eStatus != FLASH_COMPLETE)
        {
            break;
        }
    } 
    FLASH_Lock();

//    if(eStatus != FLASH_COMPLETE)
//    {
//        printf("\r\nFlash Program Failed at:0x%08x",u32FlashAddress + i);
//    }
//    else
//    {
//        printf("\r\nFlash Program ok");
//    }   

}

static uint32_t Flash_Read(uint32_t u32FlashAddress)
{
    return *(__IO uint32_t*)(u32FlashAddress);
}

/* ----------------------------- end of Static Flash functions -------------------------------------*/

#if 1
 /* -----------------------------start of Flash functions -------------------------------------*/
DATA_BUFF DataBuf = {0};
uint16_t Flash_addr = 0;
 
void Flash_WriteData(void)
{
	if((Flash_addr % PAGE_SIZE) == 0x00)
	{
			printf("Flash_offset:0x%08x ",Flash_addr);
			printf(",Flash_Erase:0x%08x, ",FLASH_OP_ADDR + Flash_addr);
			Flash_Erase(FLASH_OP_ADDR + Flash_addr);
	}
	printf(",Write Data:0x%08x ",DataBuf.u32Data);
	Flash_Write(FLASH_OP_ADDR + Flash_addr, &DataBuf.u8Data[0],4);	
}


void Flash_ReadData(void)
{
  uint32_t temp1 =  FLASH_OP_ADDR + Flash_addr;
  uint32_t temp2 =  Flash_Read(FLASH_OP_ADDR + Flash_addr);
  printf(", Read Flash Addr:0x%08x , Data:0x%08x\r\n\r\n",temp1,temp2); 
	Flash_addr += 0x04;
	
	if(Flash_addr >= FLASH_SIZE)
	{
		Flash_addr = 0; 
        while(1)
        {}
	}
}

void Flash_OB_Write(void)
{
	 uint32_t OB_Value[7];
	 uint8_t i;
	 FLASH_Status FLASHStatus;
	 OB_Value[0] = *(__IO uint32_t*)0x1FFFF000; 
   OB_Value[1] = *(__IO uint32_t*)0x1FFFF004; 
	 OB_Value[2] = *(__IO uint32_t*)0x1FFFF008; 
	 OB_Value[3] = *(__IO uint32_t*)0x1FFFF00c; 
	 OB_Value[4] = *(__IO uint32_t*)0x1FFFF010; 
	 OB_Value[5] = *(__IO uint32_t*)0x1FFFF014; 
	 OB_Value[6] = *(__IO uint32_t*)0x1FFFF018;  	
	/* Unlock the Flash Program Erase controller */  
	 FLASH_Unlock();  
	 FLASH_OB_Unlock();  
	 FLASHStatus = FLASH_OB_Erase();// 
//	 if( (OB_Value[6] & 0xFFFF0000) != 0x34560000)
//	 {
		/* Erase the WRP option Bytes*/
		
//		FLASH_OB_WRPConfig(OB_WRP_None);// write protect none
		FLASH_OB_RDPConfig(OB_RDP_Level_1); 
//		FLASH_OB_ProgramData(0x1FFFF000, 0x00FF55AA);//
//		OB_Value[0]=0x00FF55AA;
//		OB_Value[6] &= 0x0000FFFF;
//		OB_Value[6] |= 0x34560000;  
//		for(i=0;i<7;i++)
//		{
//			FLASH_OB_ProgramData(0x1FFFF000+i*4, OB_Value[i]);//??0x3456?NRST?PA0???
//		}
	// }
	 FLASH_OB_Lock();  
	 FLASH_Lock(); 	
}
#endif 
/* ----------------------------- end of Flash functions -------------------------------------*/
