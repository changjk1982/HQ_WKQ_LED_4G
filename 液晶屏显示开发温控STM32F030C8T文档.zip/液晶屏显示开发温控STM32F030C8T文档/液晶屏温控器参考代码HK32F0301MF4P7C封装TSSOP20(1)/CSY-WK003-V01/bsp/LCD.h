#ifndef __LCD_H
#define __LCD_H
//#include "config.h"
#include "ht1621.h"
//#include "user.h"
//#include "Voltage.h"

typedef enum _SMG_LED_BIT_t {
    LED_A = 0,
    LED_B,
    LED_C,
    LED_D,
    LED_E,
    LED_F,
    LED_G,
    LED_DP,
} SMG_LED_BIT_t;


#define SMG_LED_BIT(Word, bit) ((((Word) & (1 << (bit)))) ? 1 : 0)


extern unsigned char bUpdateLCD;
extern void lcd_display(void);
extern void LCDDisplayProcess(void);
extern void LCDInit(void);

#endif