#ifndef __HT1621_H
#define __HT1621_H
#include "main.h"
//#include "config.h"

#define BIAS 0x52 //0b1000 0101 0010 1/3duty 4com
//#define BIAS 0x50 //0b1000 0101 0000 1/2duty 4com


#define SYSDIS 0X00 //0b1000 0000 0000 ����ϵͳ������LCDƫѹ������
#define SYSEN 0X02  //0b1000 0000 0010 ��ϵͳ����

#define LCDOFF 0X04  //0b1000 0000 0100 ��LCDƫѹ
#define LCDON 0X06   //0b1000 0000 0110 ��LCDƫѹ
#define XTAL 0x28    //0b1000 0010 1000 �ⲿ��ʱ��
#define RC256 0X30   //0b1000 0011 0000 �ڲ�ʱ��
#define TONEON 0X12  //0b1000 0001 0010 ���������
#define TONEOFF 0X10 //0b1000 0001 0000 �ر��������
#define WDTDIS 0X0A  //0b1000 0000 1010 ��ֹ���Ź�


/**************************************************************
HT1621 48��˵����    ����SEG������LCD���ĸ����ţ����ܸ���LCD
								 ��ֵ���϶�Ӧ���ŵ���ʾ��
											SEG0��COM1��COM2��COM3��COM4ռ�����е�
								 һ���ֽڵĸ���λ��8��4��2��1λ��
											SEG1��COM1��COM2��COM3��COM4ռ�����е�
								 һ���ֽڵĵ���λ��8��4��2��1λ��
											�������ƣ�32��SEG���ܹ�ռ�����е�16����
									�ڡ�
***************************************************************/
#define SEG0_COM1_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x80;
#define SEG0_COM1_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0x7F;
#define SEG0_COM2_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x40;
#define SEG0_COM2_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0xBF;
#define SEG0_COM3_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x20;
#define SEG0_COM3_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0xDF;
#define SEG0_COM4_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x10;
#define SEG0_COM4_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0xEF;

#define SEG1_COM1_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x08;
#define SEG1_COM1_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0xF7;
#define SEG1_COM2_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x04;
#define SEG1_COM2_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0xFB;
#define SEG1_COM3_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x02;
#define SEG1_COM3_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0xFD;
#define SEG1_COM4_On  Ht1621Tab1[0]=Ht1621Tab1[0]|0x01;
#define SEG1_COM4_Off Ht1621Tab1[0]=Ht1621Tab1[0]&0xFE;

#define SEG2_COM1_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x80;
#define SEG2_COM1_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0x7F;
#define SEG2_COM2_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x40;
#define SEG2_COM2_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0xBF;
#define SEG2_COM3_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x20;
#define SEG2_COM3_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0xDF;
#define SEG2_COM4_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x10;
#define SEG2_COM4_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0xEF;

#define SEG3_COM1_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x08;
#define SEG3_COM1_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0xF7;
#define SEG3_COM2_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x04;
#define SEG3_COM2_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0xFB;
#define SEG3_COM3_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x02;
#define SEG3_COM3_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0xFD;
#define SEG3_COM4_On  Ht1621Tab1[1]=Ht1621Tab1[1]|0x01;
#define SEG3_COM4_Off Ht1621Tab1[1]=Ht1621Tab1[1]&0xFE;

#define SEG4_COM1_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x80;
#define SEG4_COM1_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0x7F;
#define SEG4_COM2_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x40;
#define SEG4_COM2_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0xBF;
#define SEG4_COM3_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x20;
#define SEG4_COM3_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0xDF;
#define SEG4_COM4_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x10;
#define SEG4_COM4_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0xEF;

#define SEG5_COM1_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x08;
#define SEG5_COM1_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0xF7;
#define SEG5_COM2_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x04;
#define SEG5_COM2_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0xFB;
#define SEG5_COM3_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x02;
#define SEG5_COM3_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0xFD;
#define SEG5_COM4_On  Ht1621Tab1[2]=Ht1621Tab1[2]|0x01;
#define SEG5_COM4_Off Ht1621Tab1[2]=Ht1621Tab1[2]&0xFE;

#define SEG6_COM1_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x80;
#define SEG6_COM1_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0x7F;
#define SEG6_COM2_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x40;
#define SEG6_COM2_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0xBF;
#define SEG6_COM3_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x20;
#define SEG6_COM3_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0xDF;
#define SEG6_COM4_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x10;
#define SEG6_COM4_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0xEF;

#define SEG7_COM1_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x08;
#define SEG7_COM1_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0xF7;
#define SEG7_COM2_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x04;
#define SEG7_COM2_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0xFB;
#define SEG7_COM3_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x02;
#define SEG7_COM3_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0xFD;
#define SEG7_COM4_On  Ht1621Tab1[3]=Ht1621Tab1[3]|0x01;
#define SEG7_COM4_Off Ht1621Tab1[3]=Ht1621Tab1[3]&0xFE;

#define SEG8_COM1_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x80;
#define SEG8_COM1_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0x7F;
#define SEG8_COM2_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x40;
#define SEG8_COM2_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0xBF;
#define SEG8_COM3_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x20;
#define SEG8_COM3_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0xDF;
#define SEG8_COM4_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x10;
#define SEG8_COM4_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0xEF;

#define SEG9_COM1_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x08;
#define SEG9_COM1_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0xF7;
#define SEG9_COM2_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x04;
#define SEG9_COM2_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0xFB;
#define SEG9_COM3_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x02;
#define SEG9_COM3_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0xFD;
#define SEG9_COM4_On  Ht1621Tab1[4]=Ht1621Tab1[4]|0x01;
#define SEG9_COM4_Off Ht1621Tab1[4]=Ht1621Tab1[4]&0xFE;

#define SEG10_COM1_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x80;
#define SEG10_COM1_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0x7F;
#define SEG10_COM2_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x40;
#define SEG10_COM2_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0xBF;
#define SEG10_COM3_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x20;
#define SEG10_COM3_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0xDF;
#define SEG10_COM4_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x10;
#define SEG10_COM4_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0xEF;

#define SEG11_COM1_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x08;
#define SEG11_COM1_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0xF7;
#define SEG11_COM2_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x04;
#define SEG11_COM2_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0xFB;
#define SEG11_COM3_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x02;
#define SEG11_COM3_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0xFD;
#define SEG11_COM4_On  Ht1621Tab1[5]=Ht1621Tab1[5]|0x01;
#define SEG11_COM4_Off Ht1621Tab1[5]=Ht1621Tab1[5]&0xFE;

#define SEG12_COM1_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x80;
#define SEG12_COM1_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0x7F;
#define SEG12_COM2_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x40;
#define SEG12_COM2_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0xBF;
#define SEG12_COM3_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x20;
#define SEG12_COM3_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0xDF;
#define SEG12_COM4_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x10;
#define SEG12_COM4_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0xEF;

#define SEG13_COM1_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x08;
#define SEG13_COM1_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0xF7;
#define SEG13_COM2_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x04;
#define SEG13_COM2_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0xFB;
#define SEG13_COM3_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x02;
#define SEG13_COM3_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0xFD;
#define SEG13_COM4_On  Ht1621Tab1[6]=Ht1621Tab1[6]|0x01;
#define SEG13_COM4_Off Ht1621Tab1[6]=Ht1621Tab1[6]&0xFE;

#define SEG14_COM1_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x80;
#define SEG14_COM1_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0x7F;
#define SEG14_COM2_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x40;
#define SEG14_COM2_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0xBF;
#define SEG14_COM3_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x20;
#define SEG14_COM3_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0xDF;
#define SEG14_COM4_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x10;
#define SEG14_COM4_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0xEF;

#define SEG15_COM1_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x08;
#define SEG15_COM1_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0xF7;
#define SEG15_COM2_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x04;
#define SEG15_COM2_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0xFB;
#define SEG15_COM3_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x02;
#define SEG15_COM3_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0xFD;
#define SEG15_COM4_On  Ht1621Tab1[7]=Ht1621Tab1[7]|0x01;
#define SEG15_COM4_Off Ht1621Tab1[7]=Ht1621Tab1[7]&0xFE;

#define SEG16_COM1_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x80;
#define SEG16_COM1_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0x7F;
#define SEG16_COM2_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x40;
#define SEG16_COM2_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0xBF;
#define SEG16_COM3_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x20;
#define SEG16_COM3_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0xDF;
#define SEG16_COM4_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x10;
#define SEG16_COM4_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0xEF;

#define SEG17_COM1_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x08;
#define SEG17_COM1_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0xF7;
#define SEG17_COM2_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x04;
#define SEG17_COM2_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0xFB;
#define SEG17_COM3_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x02;
#define SEG17_COM3_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0xFD;
#define SEG17_COM4_On  Ht1621Tab1[8]=Ht1621Tab1[8]|0x01;
#define SEG17_COM4_Off Ht1621Tab1[8]=Ht1621Tab1[8]&0xFE;

#define SEG18_COM1_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x80;
#define SEG18_COM1_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0x7F;
#define SEG18_COM2_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x40;
#define SEG18_COM2_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0xBF;
#define SEG18_COM3_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x20;
#define SEG18_COM3_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0xDF;
#define SEG18_COM4_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x10;
#define SEG18_COM4_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0xEF;

#define SEG19_COM1_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x08;
#define SEG19_COM1_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0xF7;
#define SEG19_COM2_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x04;
#define SEG19_COM2_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0xFB;
#define SEG19_COM3_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x02;
#define SEG19_COM3_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0xFD;
#define SEG19_COM4_On  Ht1621Tab1[9]=Ht1621Tab1[9]|0x01;
#define SEG19_COM4_Off Ht1621Tab1[9]=Ht1621Tab1[9]&0xFE;

#define SEG20_COM1_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x80;
#define SEG20_COM1_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0x7F;
#define SEG20_COM2_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x40;
#define SEG20_COM2_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0xBF;
#define SEG20_COM3_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x20;
#define SEG20_COM3_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0xDF;
#define SEG20_COM4_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x10;
#define SEG20_COM4_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0xEF;

#define SEG21_COM1_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x08;
#define SEG21_COM1_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0xF7;
#define SEG21_COM2_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x04;
#define SEG21_COM2_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0xFB;
#define SEG21_COM3_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x02;
#define SEG21_COM3_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0xFD;
#define SEG21_COM4_On  Ht1621Tab1[10]=Ht1621Tab1[10]|0x01;
#define SEG21_COM4_Off Ht1621Tab1[10]=Ht1621Tab1[10]&0xFE;

#define SEG22_COM1_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x80;
#define SEG22_COM1_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0x7F;
#define SEG22_COM2_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x40;
#define SEG22_COM2_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0xBF;
#define SEG22_COM3_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x20;
#define SEG22_COM3_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0xDF;
#define SEG22_COM4_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x10;
#define SEG22_COM4_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0xEF;

#define SEG23_COM1_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x08;
#define SEG23_COM1_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0xF7;
#define SEG23_COM2_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x04;
#define SEG23_COM2_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0xFB;
#define SEG23_COM3_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x02;
#define SEG23_COM3_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0xFD;
#define SEG23_COM4_On  Ht1621Tab1[11]=Ht1621Tab1[11]|0x01;
#define SEG23_COM4_Off Ht1621Tab1[11]=Ht1621Tab1[11]&0xFE;

#define SEG24_COM1_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x80;
#define SEG24_COM1_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0x7F;
#define SEG24_COM2_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x40;
#define SEG24_COM2_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0xBF;
#define SEG24_COM3_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x20;
#define SEG24_COM3_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0xDF;
#define SEG24_COM4_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x10;
#define SEG24_COM4_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0xEF;

#define SEG25_COM1_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x08;
#define SEG25_COM1_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0xF7;
#define SEG25_COM2_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x04;
#define SEG25_COM2_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0xFB;
#define SEG25_COM3_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x02;
#define SEG25_COM3_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0xFD;
#define SEG25_COM4_On  Ht1621Tab1[12]=Ht1621Tab1[12]|0x01;
#define SEG25_COM4_Off Ht1621Tab1[12]=Ht1621Tab1[12]&0xFE;

#define SEG26_COM1_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x80;
#define SEG26_COM1_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0x7F;
#define SEG26_COM2_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x40;
#define SEG26_COM2_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0xBF;
#define SEG26_COM3_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x20;
#define SEG26_COM3_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0xDF;
#define SEG26_COM4_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x10;
#define SEG26_COM4_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0xEF;

#define SEG27_COM1_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x08;
#define SEG27_COM1_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0xF7;
#define SEG27_COM2_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x04;
#define SEG27_COM2_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0xFB;
#define SEG27_COM3_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x02;
#define SEG27_COM3_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0xFD;
#define SEG27_COM4_On  Ht1621Tab1[13]=Ht1621Tab1[13]|0x01;
#define SEG27_COM4_Off Ht1621Tab1[13]=Ht1621Tab1[13]&0xFE;

#define SEG28_COM1_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x80;
#define SEG28_COM1_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0x7F;
#define SEG28_COM2_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x40;
#define SEG28_COM2_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0xBF;
#define SEG28_COM3_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x20;
#define SEG28_COM3_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0xDF;
#define SEG28_COM4_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x10;
#define SEG28_COM4_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0xEF;

#define SEG29_COM1_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x08;
#define SEG29_COM1_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0xF7;
#define SEG29_COM2_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x04;
#define SEG29_COM2_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0xFB;
#define SEG29_COM3_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x02;
#define SEG29_COM3_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0xFD;
#define SEG29_COM4_On  Ht1621Tab1[14]=Ht1621Tab1[14]|0x01;
#define SEG29_COM4_Off Ht1621Tab1[14]=Ht1621Tab1[14]&0xFE;

#define SEG30_COM1_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x80;
#define SEG30_COM1_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0x7F;
#define SEG30_COM2_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x40;
#define SEG30_COM2_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0xBF;
#define SEG30_COM3_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x20;
#define SEG30_COM3_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0xDF;
#define SEG30_COM4_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x10;
#define SEG30_COM4_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0xEF;

#define SEG31_COM1_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x08;
#define SEG31_COM1_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0xF7;
#define SEG31_COM2_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x04;
#define SEG31_COM2_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0xFB;
#define SEG31_COM3_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x02;
#define SEG31_COM3_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0xFD;
#define SEG31_COM4_On  Ht1621Tab1[15]=Ht1621Tab1[15]|0x01;
#define SEG31_COM4_Off Ht1621Tab1[15]=Ht1621Tab1[15]&0xFE;



#define HT1621_CS_CLR GPIO_ResetBits(LCD_CS_GPIO_Port,LCD_CS_Pin)//HAL_GPIO_WritePin(LCD_CS_GPIO_Port,LCD_CS_Pin,GPIO_PIN_RESET)
#define HT1621_CS_SET GPIO_SetBits(LCD_CS_GPIO_Port,LCD_CS_Pin)//HAL_GPIO_WritePin(LCD_CS_GPIO_Port,LCD_CS_Pin,GPIO_PIN_SET)


#define HT1621_WR_CLR GPIO_ResetBits(LCD_WR_GPIO_Port,LCD_WR_Pin)//HAL_GPIO_WritePin(LCD_WR_GPIO_Port,LCD_WR_Pin,GPIO_PIN_RESET)
#define HT1621_WR_SET GPIO_SetBits(LCD_WR_GPIO_Port,LCD_WR_Pin)//HAL_GPIO_WritePin(LCD_WR_GPIO_Port,LCD_WR_Pin,GPIO_PIN_SET)

#define HT1621_DAT_CLR GPIO_ResetBits(LCD_DATA_GPIO_Port,LCD_DATA_Pin)//HAL_GPIO_WritePin(LCD_DATA_GPIO_Port,LCD_DATA_Pin,GPIO_PIN_RESET)
#define HT1621_DAT_SET GPIO_SetBits(LCD_DATA_GPIO_Port,LCD_DATA_Pin)//HAL_GPIO_WritePin(LCD_DATA_GPIO_Port,LCD_DATA_Pin,GPIO_PIN_SET)

#define Power_Down GPIO_ResetBits(BACKLIT_GPIO_Port,BACKLIT_Pin)//HAL_GPIO_WritePin(BACKLIT_GPIO_Port,BACKLIT_Pin,GPIO_PIN_RESET)
#define Power_Set  GPIO_SetBits(BACKLIT_GPIO_Port,BACKLIT_Pin)//HAL_GPIO_WritePin(BACKLIT_GPIO_Port,BACKLIT_Pin,GPIO_PIN_SET)

void Ht1621_Init(void);
void Ht1621WrAllData(uint8_t Addr, uint8_t *p, uint8_t cnt);
void Ht1621WrOneData(uint8_t Addr, uint8_t Data);
void Ht1621WrCmd(uint8_t Cmd);
void Ht1621_GPIO_Init(void);
void Ht1621Wr_Data(uint8_t Data, uint8_t cnt);
void Ht1621_Clear_Buff(void);

extern uint8_t Ht1621Tab1[];
extern uint8_t Ht1621Tab2[];


#endif
