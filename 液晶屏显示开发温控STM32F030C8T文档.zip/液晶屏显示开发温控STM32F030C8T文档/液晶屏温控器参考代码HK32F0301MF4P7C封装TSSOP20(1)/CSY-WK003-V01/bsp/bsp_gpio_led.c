/*
********************************************************************************
** @file    : bsp_gpio_led.c
** @author  : 
** @version : 
** @date    : 
** @brief   : 
********************************************************************************
*/
  
/*==============================================================================
** Includes
==============================================================================*/
#include "bsp_gpio_led.h"

/*==============================================================================
** Private typedef
==============================================================================*/

/*==============================================================================
** Private macro
==============================================================================*/

/*==============================================================================
** Private define
==============================================================================*/

/*==============================================================================
** Private variables
==============================================================================*/
/* GPIO configurations */
GPIO_TypeDef* GPIO_PORT[GPIOn]              = {GPIO_LED1_PORT, 
                                               GPIO_LED2_PORT, 
                                               GPIO_LED3_PORT};
								 
const uint16_t GPIO_PIN[GPIOn]              = {GPIO_LED1_PIN, 
                                               GPIO_LED2_PIN,
								                               GPIO_LED3_PIN};
								 
const uint32_t GPIO_CLK[GPIOn]              = {GPIO_LED1_CLK, 
                                               GPIO_LED2_CLK,
								                               GPIO_LED3_CLK};

const GPIOMode_TypeDef GPIO_MODE[GPIOn]     = {GPIO_LED1_MODE,
											   GPIO_LED2_MODE,
                                               GPIO_LED3_MODE};

const GPIOSpeed_TypeDef GPIO_SPEED[GPIOn]   = {GPIO_LED1_SPEED,
								               GPIO_LED2_SPEED,
                                               GPIO_LED3_SPEED};
								   
const GPIOOType_TypeDef GPIO_OTYPE[GPIOn]   = {GPIO_LED1_OTYPE,
								                               GPIO_LED2_OTYPE,
                                               GPIO_LED3_OTYPE};

const GPIOPuPd_TypeDef GPIO_PUPD[GPIOn]     = {GPIO_LED1_PUPD,
								                               GPIO_LED2_PUPD,
                                               GPIO_LED3_PUPD};													 

const GPIOSchmit_TypeDef GPIO_SCHMIT[GPIOn] = {GPIO_LED1_SCHMIT,
								                               GPIO_LED2_SCHMIT,
                                               GPIO_LED3_SCHMIT};	

const Gpio_State GPIO_STATE[GPIOn]          = {GPIO_LED1_INITSTATE,
								                               GPIO_LED2_INITSTATE,
                                               GPIO_LED3_INITSTATE};

																							 
/*==============================================================================
** Private function prototypes
==============================================================================*/


/******************************************************************************/
/*                          Function Implementation                           */
/******************************************************************************/
/*******************************************************************************
** @function : BSP_GPIO_Init
** @brief    : Initializes GPIO 
** @param    : Gpio - Specifies the GPIO to be initialized																
** @retval   : None
*******************************************************************************/
void BSP_GPIO_Init(Gpio_TypeDef Gpio)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
  
  /* Enable GPIO clock */
  RCC_AHBPeriphClockCmd(GPIO_CLK[Gpio], ENABLE);

  /* Configure and initialize GPIO */
  GPIO_InitStructure.GPIO_Pin = GPIO_PIN[Gpio];
  GPIO_InitStructure.GPIO_Mode = GPIO_MODE[Gpio];
  GPIO_InitStructure.GPIO_Speed = GPIO_SPEED[Gpio];
  GPIO_InitStructure.GPIO_OType = GPIO_OTYPE[Gpio];
  GPIO_InitStructure.GPIO_PuPd = GPIO_PUPD[Gpio];
	GPIO_InitStructure.GPIO_Schmit = GPIO_SCHMIT[Gpio];
  GPIO_Init(GPIO_PORT[Gpio], &GPIO_InitStructure);
  
  /* Set GPIO initial state */
  if (GPIO_MODE[Gpio] == GPIO_Mode_OUT)
  {
	  if (GPIO_STATE[Gpio] == LOW)
	  {
			/* Set GPIO initial state to LOW */
	    GPIO_PORT[Gpio]->BRR |= GPIO_PIN[Gpio];
	  }
	  else
	  {
			/* Set GPIO initial state to HIGH */
	    GPIO_PORT[Gpio]->BSRR |= GPIO_PIN[Gpio];
	  }
  }
}


/*******************************************************************************
** @function : BSP_GPIO_SetHigh
** @brief    : Set GPIO to high level 
** @param    : Gpio - Specifies the GPIO to be set																
** @retval   : None
*******************************************************************************/
void BSP_GPIO_SetHigh(Gpio_TypeDef Gpio)
{
	GPIO_PORT[Gpio]->BSRR |= GPIO_PIN[Gpio];
}


/*******************************************************************************
** @function : BSP_GPIO_SetLow
** @brief    : Set GPIO to low level 
** @param    : Gpio - Specifies the GPIO to be set																
** @retval   : None
*******************************************************************************/
void BSP_GPIO_SetLow(Gpio_TypeDef Gpio)
{
	GPIO_PORT[Gpio]->BRR |= GPIO_PIN[Gpio];
}


/*******************************************************************************
** @function : BSP_GPIO_Toggle
** @brief    : Toggle GPIO 
** @param    : Gpio - Specifies the GPIO to be toggled																
** @retval   : None
*******************************************************************************/
void BSP_GPIO_Toggle(Gpio_TypeDef Gpio)
{
	GPIO_PORT[Gpio]->ODR ^= GPIO_PIN[Gpio];
}


/*******************************************************************************
** @function : BSP_LED_Init
** @brief    : Initializes LED 
** @param    : Led - Specifies the LED to be initialized																
** @retval   : None
*******************************************************************************/
void BSP_LED_Init(Gpio_TypeDef Led)
{
	 BSP_GPIO_Init(Led);
}


/*******************************************************************************
** @function : BSP_LED_TurnOn
** @brief    : Turns on LED 
** @param    : Led - Specifies the LED to be turned on																
** @retval   : None
*******************************************************************************/
void BSP_LED_TurnOn(Gpio_TypeDef Led)
{
	BSP_GPIO_SetLow(Led);
}


/*******************************************************************************
** @function : BSP_LED_TurnOff
** @brief    : Turns off LED 
** @param    : Led - Specifies the LED to be turned off																
** @retval   : None
*******************************************************************************/
void BSP_LED_TurnOff(Gpio_TypeDef Led)
{
	BSP_GPIO_SetHigh(Led);
}


/*******************************************************************************
** @function : BSP_LED_Toggle
** @brief    : Toggles LED 
** @param    : Led - Specifies the LED to be toggled																
** @retval   : None
*******************************************************************************/
void BSP_LED_Toggle(Gpio_TypeDef Led)
{
	BSP_GPIO_Toggle(Led);
}


/*********************************** EOF **************************************/
