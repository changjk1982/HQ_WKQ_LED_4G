#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "hk32f0301mxxc.h"
#define HAL_MAX_DELAY      0xFFFFFFFFU

void SysTick_Init(void);
void Delay_us(__IO uint32_t nTime);
#define Delay_ms(x)  Delay_us(100*x)   // ��λms

void SysTick_Delay_Us( __IO uint32_t us);
void SysTick_Delay_Ms( __IO uint32_t ms);

uint32_t TickTimeDiff(uint32_t tick);

extern uint32_t sys_ms_tick;


#endif  /* __SYSTICK_H */























