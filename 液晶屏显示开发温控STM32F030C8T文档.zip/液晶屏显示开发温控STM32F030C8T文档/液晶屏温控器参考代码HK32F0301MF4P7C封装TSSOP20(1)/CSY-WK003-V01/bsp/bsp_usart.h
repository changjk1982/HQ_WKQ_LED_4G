/*
********************************************************************************
** @file    : bsp_usart.h
** @author  : 
** @version : 
** @date    : 
** @brief   :  
********************************************************************************
*/

#ifndef __BSP_USART_H
#define __BSP_USART_H

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================
** Includes
==============================================================================*/
#include "hk32f0301mxxc.h"

/*==============================================================================
** Exported types
==============================================================================*/
typedef enum 
{
  COM1=0,
	COM2 
} Com_TypeDef; 

/*==============================================================================
** Exported constants
==============================================================================*/

/*==============================================================================
** Exported macros
==============================================================================*/

/*==============================================================================
** Exported definitions
==============================================================================*/
#define COMn                2

#define COM1_UART           UART1
#define COM1_CLK            RCC_APBPeriph2_UART1
																		     
#define COM1_TX_PIN         GPIO_Pin_5
#define COM1_TX_GPIO_PORT   GPIOD
#define COM1_TX_GPIO_CLK    RCC_AHBPeriph_GPIOD
#define COM1_TX_SOURCE      GPIO_PinSource5
#define COM1_TX_AF          GPIO_AF_1
																		     
#define COM1_RX_PIN         GPIO_Pin_5
#define COM1_RX_GPIO_PORT   GPIOB
#define COM1_RX_GPIO_CLK    RCC_AHBPeriph_GPIOB
#define COM1_RX_SOURCE      GPIO_PinSource5
#define COM1_RX_AF          GPIO_AF_1
																		     
#define COM1_IRQn           UART1_IRQn

#define COM2_UART           UART2
#define COM2_CLK            RCC_APBPeriph1_UART2
																		     
#define COM2_TX_PIN         GPIO_Pin_3
#define COM2_TX_GPIO_PORT   GPIOA
#define COM2_TX_GPIO_CLK    RCC_AHBPeriph_GPIOA
#define COM2_TX_SOURCE      GPIO_PinSource3
#define COM2_TX_AF          GPIO_AF_6
																		     
#define COM2_RX_PIN         GPIO_Pin_2
#define COM2_RX_GPIO_PORT   GPIOA
#define COM2_RX_GPIO_CLK    RCC_AHBPeriph_GPIOA
#define COM2_RX_SOURCE      GPIO_PinSource2
#define COM2_RX_AF          GPIO_AF_6
																		     
#define COM2_IRQn           UART2_IRQn

#define UART1_TX_BUFLEN			100
#define UART1_RX_BUFLEN			100

extern unsigned char uart1_tx_buf[UART1_TX_BUFLEN];
extern unsigned char uart1_rx_buf[UART1_RX_BUFLEN];
extern unsigned char uart1_rx_complete;

extern unsigned char uart2_rx_buf[UART1_RX_BUFLEN];
extern unsigned char uart2_rx_complete;
extern unsigned char uart2_tx_cnt,uart2_tx_complete;

/*==============================================================================
** Exported functions
==============================================================================*/
void BSP_UART_Config(Com_TypeDef Com, uint32_t Baud);
void BSP_UART_SendByte(UART_TypeDef* UARTx, uint8_t Data);
void BSP_UART_SendString(UART_TypeDef* UARTx, char* Str);
void USART_NVICConfig(void);


#ifdef __cplusplus
}
#endif

#endif /* __BSP_USART_H */


/*********************************** EOF **************************************/
