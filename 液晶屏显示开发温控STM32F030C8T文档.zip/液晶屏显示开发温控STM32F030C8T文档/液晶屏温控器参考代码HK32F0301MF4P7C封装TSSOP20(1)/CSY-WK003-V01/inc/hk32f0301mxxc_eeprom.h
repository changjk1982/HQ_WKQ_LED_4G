/*
********************************************************************************
** @file    : hk32f030m_eeprom.h
** @author  : 
** @version : 
** @date    : 
** @brief   : 
********************************************************************************
*/

#ifndef __HK32F030M_EEPROM_H
#define __HK32F030M_EEPROM_H

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================
** Includes
==============================================================================*/
#include "hk32f0301mxxc.h"
#include "hk32f0301mxxc_flash.h"

/*==============================================================================
** Exported types
==============================================================================*/

/*==============================================================================
** Exported constants
==============================================================================*/

/*==============================================================================
** Exported macros
==============================================================================*/
/* hk32f030m internal EEPROM definitions */
#define HK32F030M_EE_START        (0x0C000000ul)  /* EEPROM start address */
#define HK32F030M_EE_END          (0x0C0001C0ul)  /* EEPROM end address */
//#define HK32F030M_EE_SIZE         (448)           /* EEPROM size */    
#define HK32F030M_EE_SIZE         (20)           /* EEPROM size */

/*==============================================================================
** Exported functions
==============================================================================*/
ErrorStatus intEEPROM_WriteByte(uint32_t Offset, uint8_t Data);
ErrorStatus intEEPROM_ReadByte(uint32_t Offset, uint8_t *Destination);
ErrorStatus intEEPROM_EraseByte(uint32_t Offset);
void intEEPROM_EraseAll(void);

FLASH_Status EEPROM_EraseByte(uint32_t Address);
FLASH_Status EEPROM_ProgramByte(uint32_t Address, uint8_t Data);

#ifdef __cplusplus
}
#endif

#endif /* __HK32F030M_EEPROM_H */


/*********************************** EOF **************************************/
