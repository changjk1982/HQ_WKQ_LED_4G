/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************

  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H
#include "stdint.h"
#include "stdio.h"
#include "stdlib.h"
#include "stdbool.h"
#include "hk32f0301mxxc.h"

#define NOMAL_MODE	0X01
#define F1_MODE		0X02
#define F2_MODE		0X03
#define F3_MODE		0X04
#define CAL_MODE	0X05
#define SYS_WORK_STA		0X01
#define LOCK_KEY_SETTING	0X02
#define SAVE_WORK_STA_SETTING 0X04
#define RESET_TIMER						0X08
#define HEAT_ON							0X10
#define ENABLE_BEEP					0X20

#define TEMP_SET_MAXVLUE	1200
#define CTRL_BEEP_MASK		0X04
#define CTRL_HEAT_MASK		0X02
#define ZERO_TEMP			40
#define NTC_ARRAY_CNT 		170 //-40-130

#define STOPTEMP_INDEX		6
#define STARTTEMP_INDEX		3

#define CURRENT_TEMP_NO_SENSOR	30000

#define KEY_DEBOUCE_MINCNT	10
#define KEY_DEBOUCE_MAXCNT 	600

#define KEY_LONG_PRESSED_CNT	800
#define KEY_AUTO_INTERVALCNT	120

#define BEEP_TIMEOUT_CNT		160//400MS
#define LOCK_TIMEOUT_CNT				15//SEC
#define INDEX_TIMEOUT_CNT	  		10//SEC
#define LOCK_DIS_TIMEOUT_CNT		15//SEC


#define K1_Port	 GPIOC
#define K2_Port	 GPIOC
#define K3_Port	 GPIOC
#define K4_Port	 GPIOC
//#define K5_Port	 GPIOC

#define K1_MASK				 GPIO_Pin_7 //stoptemp+ PC5
#define K2_MASK				 GPIO_Pin_6 //stoptemp- PC4
#define K3_MASK				 GPIO_Pin_5 //setting PC3
#define K4_MASK				 GPIO_Pin_4 //starttemp+ PC0
//#define K5_MASK				 GPIO_Pin_6 //starttemp- PA6

#define DIS1_Port			 GPIOD
#define DIS2_Port			 GPIOD
#define DIS3_Port			 GPIOD
#define DIS4_Port			 GPIOB
#define DIS5_Port			 GPIOA
#define DIS6_Port			 GPIOD
#define DIS7_Port			 GPIOD

#define DIS1_MASK			GPIO_Pin_3
#define DIS2_MASK			GPIO_Pin_6
#define DIS3_MASK			GPIO_Pin_2
#define DIS4_MASK			GPIO_Pin_4
#define DIS5_MASK			GPIO_Pin_1
#define DIS6_MASK			GPIO_Pin_7
#define DIS7_MASK			GPIO_Pin_1

//#define OneWirePort GPIOD
//#define OneWire_MASK		GPIO_Pin_4

#define LCD_IRQ_Pin GPIO_Pin_3
#define LCD_IRQ_GPIO_Port GPIOA
#define LCD_CS_Pin GPIO_Pin_2
#define LCD_CS_GPIO_Port GPIOA
#define LCD_WR_Pin GPIO_Pin_1
#define LCD_WR_GPIO_Port GPIOA
#define LCD_RD_Pin GPIO_PIN_0
#define LCD_RD_GPIO_Port GPIOA
#define LCD_DATA_Pin GPIO_Pin_6
#define LCD_DATA_GPIO_Port GPIOD

#define REALTEMP_DOT_ICON		0X80
#define STARTTEMP_DOT_ICON	0X80
#define STOPTEMP_DOT_ICON		0X80

#define REALTEMP_ICON			0X01//
#define RUNNING_ICON			0X02
#define CAL_ICON				  0X04
#define CYCLE_RUNNING_ICON 0X08
#define TIMING_ICON				0X10
#define TIMING_ON_ICON		0X20
#define TIMING_OFF_ICON		0X40

#define START_ICON				0X01
#define START_TEMP_ICON		0X02
#define START_TIME_ICON		0X04
#define START_MIN_ICON		0X08

#define STOP_ICON					0X10
#define STOP_TEMP_ICON		0X20
#define STOP_TIME_ICON		0X40
#define STOP_MIN_ICON			0X80



typedef unsigned char   	INT8U;        	// Unsigned  8 bit quantity
typedef signed   char   	INT8S;         	// Signed    8 bit quantity
typedef unsigned short  	INT16U;       	// Unsigned  16 bit quantity
typedef signed   short  	INT16S;        	// Signed    16 bit quantity
typedef unsigned long   	INT32U;       	// Unsigned  32 bit quantity
typedef signed   long   	INT32S;        	// Signed    32 bit quantity
typedef unsigned long long 	INT64U;			// Unsigned  64 bit quantity
typedef signed	 long long	INT64S;			// Signed    64 bit quantity
typedef float           	FP32;         	// Single    precision
typedef double          	FP64;         	// Double    precision



//#define RS485_Dir_Port	GPIOD
//#define RS485_Dir_MASK	GPIO_Pin_7
extern unsigned char display_data[11];
extern void delay_ms(unsigned int time);

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

