/*
********************************************************************************
** @file    : hk32f030m_eeprom.c
** @author  : 
** @version : 
** @date    : 
** @brief   : 
********************************************************************************
*/

/*==============================================================================
** Includes
==============================================================================*/
#include "hk32f0301mxxc_eeprom.h"

/*==============================================================================
** Private typedef
==============================================================================*/

/*==============================================================================
** Private macro
==============================================================================*/

/*==============================================================================
** Private define
==============================================================================*/

/*==============================================================================
** Private variables
==============================================================================*/

/*==============================================================================
** Private function prototypes
==============================================================================*/


/*  EEPROM_Address  16K devices */
#define IS_EEPROM_PROGRAM_ADDRESS(ADDRESS) (((ADDRESS) >= 0x0C000000) && ((ADDRESS) <= 0x0C0001C0))

/**
  * @brief  erase a byte at a EEPROM address.
  * @param  Address: specifies the address to be programmed.
  * @param  Data: specifies the data to be programmed.
  * @retval FLASH Status: The returned value can be: FLASH_ERROR_PG,
  *         FLASH_ERROR_WRP, FLASH_COMPLETE or FLASH_TIMEOUT. 
  */
FLASH_Status EEPROM_EraseByte(uint32_t Address)
{
  FLASH_Status status = FLASH_COMPLETE;

  /* Check the parameters */
  assert_param(IS_EEPROM_PROGRAM_ADDRESS(Address));

  /* Wait for last operation to be completed */
  status = FLASH_WaitForLastOperation(FLASH_ER_PRG_TIMEOUT);
  
  if(status == FLASH_COMPLETE)
  {
    /* If the previous operation is completed, proceed to program the new data */
//    FLASH->ECR |= FLASH_ECR_EEPROM_ER;  
	FLASH->AR = Address;
    FLASH->CR |= FLASH_CR_STRT;

    /* Wait for last operation to be completed */
    status = FLASH_WaitForLastOperation(FLASH_ER_PRG_TIMEOUT);
    
    /* Disable the PG Bit */
//    FLASH->ECR &= ~FLASH_ECR_EEPROM_ER;
  } 
  
  /* Return the Program Status */
  return status;
}


/**
  * @brief  Programs a byte at a EEPROM address.
  * @param  Address: specifies the address to be programmed.
  * @param  Data: specifies the data to be programmed.
  * @retval FLASH Status: The returned value can be: FLASH_ERROR_PG,
  *         FLASH_ERROR_WRP, FLASH_COMPLETE or FLASH_TIMEOUT. 
  */
FLASH_Status EEPROM_ProgramByte(uint32_t Address, uint8_t Data)
{
  FLASH_Status status = FLASH_COMPLETE;

  /* Check the parameters */
  assert_param(IS_EEPROM_PROGRAM_ADDRESS(Address));

  /* Wait for last operation to be completed */
  status = FLASH_WaitForLastOperation(FLASH_ER_PRG_TIMEOUT);
  
  if(status == FLASH_COMPLETE)
  {
    /* If the previous operation is completed, proceed to program the new data */
//    FLASH->ECR |= FLASH_ECR_EEPROM_BPG;
  
    *(__IO uint8_t*)Address = Data;

    /* Wait for last operation to be completed */
    status = FLASH_WaitForLastOperation(FLASH_ER_PRG_TIMEOUT);
    
    /* Disable the PG Bit */
//    FLASH->ECR &= ~FLASH_ECR_EEPROM_BPG;
  } 
  
  /* Return the Program Status */
  return status;
}


/******************************************************************************/
/*                          Function Implementation                           */
/******************************************************************************/
/*******************************************************************************
** @function : intEEPROM_WriteByte
** @brief    : Write a byte at an EEPROM address 
** @param    : Offset - Specifies the offset address to be written
**             Data - Specifies the data to be written
** @retval   : ErrorStatus - 0: ERROR, 1: SUCCESS
*******************************************************************************/
ErrorStatus intEEPROM_WriteByte(uint32_t Offset, uint8_t Data)
{
	/* Check the address, it must be in the range of EEPROM size */
	if(HK32F030M_EE_SIZE <= Offset)
	{
		return ERROR;
	}
	
	FLASH_Unlock();
	EEPROM_EraseByte(Offset + HK32F030M_EE_START);
	EEPROM_ProgramByte(Offset + HK32F030M_EE_START, Data);
	FLASH_Lock();
	
	/* Read out the data was written to check correct or not */
	if((*(uint8_t *)(Offset + HK32F030M_EE_START)) != Data)
	{
		return ERROR;
	}
	
	return SUCCESS;
}


/*******************************************************************************
** @function : intEEPROM_ReadByte
** @brief    : Read a byte data from an EEPROM address
** @param    : Offset - Specifies the offset address to be read 
**             Destination - Specifies destination to be stored the data
** @retval   : ErrorStatus - 0: ERROR, 1: SUCCESS
*******************************************************************************/
ErrorStatus intEEPROM_ReadByte(uint32_t Offset, uint8_t *Destination)
{
	/* Check the address, it must be in the range of EEPROM size */
	if(HK32F030M_EE_SIZE <= Offset)
	{
		return ERROR;
	}
	
	*Destination = (*((uint8_t *)(Offset + HK32F030M_EE_START)));
	
	return SUCCESS;
}


/*******************************************************************************
** @function : intEEPROM_EraseByte
** @brief    : Erase a byte data at an EEPROM address
** @param    : Offset - Specifies the offset address to be erased 
** @retval   : ErrorStatus - 0: ERROR, 1: SUCCESS
*******************************************************************************/
ErrorStatus intEEPROM_EraseByte(uint32_t Offset)
{
	/* Check the address, it must be in the range of EEPROM size */
	if(HK32F030M_EE_SIZE <= Offset)
	{
		return ERROR;
	}
	
	FLASH_Unlock();
	EEPROM_EraseByte(Offset + HK32F030M_EE_START);
	FLASH_Lock();
	
	return SUCCESS; 
}


/*******************************************************************************
** @function : intEEPROM_EraseAll
** @brief    : Erase all data in EEPROM
** @param    : None 
** @retval   : None
*******************************************************************************/
void intEEPROM_EraseAll(void)
{
  uint16_t temp;

  for (temp = 0; temp < HK32F030M_EE_SIZE; temp++)
  {	
	  FLASH_Unlock();
	  EEPROM_EraseByte(temp + HK32F030M_EE_START);
	  FLASH_Lock();
	}
}


/*********************************** EOF **************************************/
