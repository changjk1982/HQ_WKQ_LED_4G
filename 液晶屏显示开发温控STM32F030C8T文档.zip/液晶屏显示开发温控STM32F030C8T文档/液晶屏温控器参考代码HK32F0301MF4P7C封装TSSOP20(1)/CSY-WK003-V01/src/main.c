/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * @func  ����������ֲᣬ��ѡ���Լ���Ҫ����������
  * note   �ڽ���ϵͳ������ص�pin�Ÿ���ΪIO��ʱ����Ҫע�⣬�����main������ʼ������100MS���ϵ�������ʱ��
  *        ������Ϊ ����pin�Ÿ��ó�IO֮ǰ��ΪĬ�ϵĹ��ܣ�һ������ΪIO֮��Ĭ�Ϲ��ܱ�Ϊ����֮���IO���ܡ�
  *        ���������ʱ������pin�ŵ�Ĭ�Ϲ��ܻ�ܿ챻����Ϊ��IO���ܣ��ᵼ��Ĭ�Ϲ��ܻ�ûִ���ꡣ
  *        ���� NRTS--PA0    SWCLK--IO  SWD--IO  �������ǰ���һ����ʱ���ڲ�Ʒ����ʱȷ����������֮��
  *        �ɽ�����ʱȥ����
  */

/* Includes ------------------------------------------------------------------*/

#include <string.h>
#include "bsp_usart.h"
#include "bsp_SysTick.h"
#include "hk32f0301mxxc_flash.h"
#include "flash.h"
#include "main.h"
#include "LCD.h"

#define Toggle_Heat_Ctrl() CtrlByte ^= CTRL_HEAT_MASK;
typedef struct 
{	
	unsigned char pkt_id;
	unsigned char SettingMode;	
	int StopTemp;
	int StartTemp;
	unsigned int StopTime;
	unsigned int StartTime;
	unsigned int TurnOffTime;
	unsigned int TurnOnTime;
	int CalTemp;
	int params[3];
	unsigned char SysSetting;
	unsigned char crc;
	unsigned char params_set;
}SYS_PARAMS;
//                                   0    1    2    3    4    5    6    7    8    9   a     b     c   d   e    f    x     -    L     H //??
const unsigned char num_table[21]={ 0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x00,0x40,0X38,0X76,0x73};

const unsigned int NTC_ADArray[NTC_ARRAY_CNT]={ 3907,3897,3886,3875,3863,3850,3837,3824,3810,3795,3780,3764,3748,3731,3713,3695,3676,3657,\
 												3636,3615,3594,3571,3548,3525,3500,3475,3449,3423,3396,3368,3339,\
									    		3294,3264,3233,3202,3170,3137,3104,3070,3036,3001,2966,2930,2894,2857,2820,2782,2745,2706,2668,2629,\
									   			2590,2551,2506,2467,2428,2388,2349,2310,2271,2231,2192,2153,2115,2076,2038,1999,1960,1922,1884,1846,\
									   			1808,1771,1735,1699,1663,1627,1592,1558,1524,1491,1458,1425,1393,1362,1331,1300,1271,1241,1213,1184,\
									   			1157,1130,1103,1077,1052,1028,1003,979,956,933,910,889,867,846,826,806,786,767,749,731,\
									   			713,696,679,662,646,630,615,600,586,572,558,544,531,518,506,494,482,471,459,448,\
									   			438,427,417,407,398,388,379,370,361,353,345,337,329,321,314,307,300,293,286,\
													279,273,267,261,255,249,244,238,233,228,218,213,208,204,200,196,192,189,186,183 
};	//-40-130


unsigned int sys_tick=0;
unsigned char key_tmp=0,key=0;
unsigned char key_debouce=0;
unsigned char CalTempMode=0;
unsigned char display_data[11]={0,0,0,0,0,0,0,0,0,0,0};//digital 0-8,other lable
unsigned char dig_data[11]={0,0,0,0,0,0,0,0,0,0,0};
unsigned char TempHByte=255,TempLByte=255,TempInt=0,TempFrag=0,HumityInt=0,HumityFrag=0;
unsigned char CtrlByte=0,Crc=0;//BIT7-BIT3:CAL TEMP,BIT2:BEEP BIT1:HEAT BIT0:ODD
unsigned int adc_temp,adc_result[10],real_temp=0;
unsigned char bUpdateData=1,toggle_temp_display=0 ;
unsigned char DisDigitCnt=0;
unsigned int key_pressed_cnt[5]={0,0,0,0,0};
unsigned int min=0;
unsigned char bSaveParams=0;
unsigned long int adc_sum=0;
unsigned int adc_debouce_cnt=0;
unsigned char adc_array_cnt=0;
unsigned char bStartCalADC=0;
unsigned char bPlugNTC=0,bPlugAHD=0,bPlugSHD=0;
unsigned int bHumityWDTCnt=0;
unsigned char bHumitySet=0;
int max_key_value,min_key_value;
unsigned char SensorType=0;
SYS_PARAMS sSysParams;
//int params_tmp=0;
int runing_time;//min
unsigned char sys_sec=0;
//unsigned char sys_min=0;
unsigned char bSetLVD=0;
unsigned char bResetTimer=0;
unsigned int BeepTimeTick=BEEP_TIMEOUT_CNT;
unsigned char BeepCnt=0;
unsigned char CheckAHD=1;
unsigned char bToggleDisplay=0;
unsigned char EnableRelay=0;
unsigned char icon_index=0;
unsigned char icon_timecnt=0;
unsigned char bStartRunSys=0;
unsigned char lock_key_timecnt=LOCK_TIMEOUT_CNT;
unsigned char lock_key=0;
unsigned char lock_key_index=1;
unsigned char lock_key_display_time=0;
unsigned char EnableCalMode=1;
unsigned char bResetParams=0;
char password[2]={0,0};
int current_temp=CURRENT_TEMP_NO_SENSOR;

void SysTick_Handler(void);													
void SysInit(void);
void SetSysDefaultParams(void);
void GPIO_Config(void);
void ADC_Configuration(void);
void GetADC(void);
void temp_func(void);
void SensorValDis(void);
void disdata_conveter(unsigned char *disbuf,int data);
void key_pro(void);
void key_func(unsigned char keycmd);
void key_scan(void);
void delay_ms(unsigned int ms);
unsigned int NTCADBinarySearch(unsigned int CurrentAD);
void update_lcd(void);
unsigned int GetADCResult(unsigned int *adc_data_ptr);
void delay_us(unsigned int time);													
void delay_ms(unsigned int time);	
void beep(void);													
void SaveParams(void);
void RestoreParams(void);
void SysCtrl(void);
void AHD_Pro(void);
void uart_pro(void);
/*==============================================================================
** Private function prototypes
==============================================================================*/

/******************************************************************************/
/*                          Function Implementation                           */
/******************************************************************************/
/*******************************************************************************
** @function : main
** @brief    :   
** @param    : None
** @retval   : None
*******************************************************************************/
int main(void)
{  
	SysInit();
	while(1)
	{		
		update_lcd();
//		uart_pro();
//		AHD_Pro();	
		if((SensorType==0)&&(sSysParams.SettingMode==NOMAL_MODE))
			bStartRunSys=0;	
		beep();
		
		if((CtrlByte&CTRL_HEAT_MASK)&&bStartRunSys)// set output
		{
				GPIO_SetBits(GPIOD,GPIO_Pin_4);	
		}
		else //turn off
		{
				GPIO_ResetBits(GPIOD,GPIO_Pin_4);	
		}
		SaveParams();
	}
}

void SysInit(void)
{
	delay_ms(100);
	/* USART configuration with 9600 baud rate */
//	BSP_UART_Config(COM1, 2400);		
//	USART_NVICConfig();
	GPIO_Config();
//	printf("\r\nUART1 Start!BR:9600\r\n");
//	BSP_UART_SendString(UART1,"Air780E&DEBUG UART1\r\n");	
	/* USART configuration with 2400 baud rate */
//	BSP_UART_Config(COM2, 2400);
//	USART_NVICConfig();
	delay_ms(130);	//volt stable
//	GPIO_SetBits(GPIOD,GPIO_Pin_7);
//	BSP_UART_SendString(UART2,"DEV\r\n");
//	GPIO_ResetBits(GPIOD,GPIO_Pin_7);
  delay_ms(100);	//volt stable
	LCDInit();
//	uart_pro();
	ADC_Configuration();
//	Flash_OB_Write();  
	SysTick_Init(); 
	RestoreParams();
	if(sSysParams.SettingMode>=5||sSysParams.SettingMode==0||sSysParams.params_set!=0xAA)
	{
		SetSysDefaultParams();
	}	
	
		
	if((sSysParams.SysSetting&(SYS_WORK_STA|SAVE_WORK_STA_SETTING))==(SYS_WORK_STA|SAVE_WORK_STA_SETTING))
	{
		bStartRunSys=1;
		if(sSysParams.SysSetting&RESET_TIMER)
		{
				bResetTimer=1;
				BeepCnt=5;
		}
	}
	if(sSysParams.SettingMode==F2_MODE)
	{
		if(bResetTimer)
			CtrlByte |=CTRL_HEAT_MASK;		
	//	runing_time=sSysParams.TurnOnTime;		
	}
	else if(sSysParams.SettingMode==F3_MODE)
	{
		if(bResetTimer==0)
			CtrlByte |=CTRL_HEAT_MASK;
		//runing_time=sSysParams.TurnOffTime;
	}	
	else if(sSysParams.SettingMode==F1_MODE)
	{
		CtrlByte |=CTRL_HEAT_MASK;
	}
	runing_time=sSysParams.params[0];
	delay_ms(20);
	if ((key&0x08)==0) EnableCalMode=0;
}
void SetSysDefaultParams(void)
{
		sSysParams.pkt_id=0x0A;
		sSysParams.SettingMode=NOMAL_MODE;	
		sSysParams.StopTemp=250;
		sSysParams.StartTemp=200;
		if(bPlugAHD||bPlugSHD)
		{
			sSysParams.StopTemp=99;//80 
			sSysParams.StartTemp=69;//50
		}
		sSysParams.StopTime=10;//F1 MODE
		sSysParams.StartTime=10;
		sSysParams.TurnOffTime=60;//F2 MODE
		sSysParams.TurnOnTime=60; //F3 MODE
		sSysParams.CalTemp=0;
		sSysParams.params[0]=sSysParams.StartTemp;
		sSysParams.params[1]=sSysParams.StopTemp;
		sSysParams.SysSetting=SAVE_WORK_STA_SETTING|ENABLE_BEEP;
		sSysParams.params_set=0XAA;	
		
}
void GPIO_Config(void)
{		
	GPIO_InitTypeDef GPIO_InitStructure;	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD|RCC_AHBPeriph_GPIOA|RCC_AHBPeriph_GPIOB|RCC_AHBPeriph_GPIOC, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;

  /*������������Ϊ50MHz */   
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_1; 
	GPIO_InitStructure.GPIO_PuPd =GPIO_PuPd_NOPULL;

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_2|GPIO_Pin_6|GPIO_Pin_4;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOD,GPIO_Pin_4);	
	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2; 	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOC,GPIO_Pin_3);	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
//	GPIO_Init(GPIOC, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;  
	GPIO_InitStructure.GPIO_PuPd =GPIO_PuPd_UP;
		
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	//ADC IN
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	
//	RCC_APBPeriph1ClockCmd(RCC_APBPeriph1_IOMUX,ENABLE);
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
//	GPIO_IOMUX_ChangePin(IOMUX_PIN7,IOMUX_NRST_SEL_PA0);// change to PA0	
//	GPIO_Init(GPIOA, &GPIO_InitStructure);

//	RCC_APBPeriph1ClockCmd(RCC_APBPeriph1_IOMUX,ENABLE);
  
//  IOMUX->NRST_PIN_KEY = NRST_PINKEY;
//  IOMUX->PKG_PIN_SEL &= IOMUX_NRST_SEL_MASK;//clear select bits(0)
//  IOMUX->NRST_PIN_KEY = NRST_PINKEY;
//  IOMUX->PKG_PIN_SEL |= IOMUX_NRST_SEL_PA0;
//  
//  IOMUX->NRST_PIN_KEY = NRST_PINKEY;
//  IOMUX->NRST_PA0_SEL |= (uint32_t)(0x00000001);
//  GPIO_Init(GPIOA, &GPIO_InitStructure);	
	
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;  
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
//	GPIO_InitStructure.GPIO_PuPd =GPIO_PuPd_UP;
//	GPIO_Init(GPIOD, &GPIO_InitStructure);
//	GPIO_SetBits(OneWirePort,OneWire_MASK);
//	GPIO_ResetBits(RS485_Dir_Port,RS485_Dir_MASK);	
}

void ADC_Configuration(void)
{
	NVIC_InitTypeDef    NVIC_InitStructure;
	ADC_InitTypeDef ADC_InitStructure;
	RCC_APBPeriph2ClockCmd(RCC_APBPeriph2_ADC ,ENABLE);
	ADC_DeInit(ADC);
	ADC_StructInit(&ADC_InitStructure);
	
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
//  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_TRGO;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_ScanDirection = ADC_ScanDirection_Upward;
  ADC_Init(ADC,&ADC_InitStructure);
  /* ADC1 regular channels configuration */ 
  ADC_ChannelConfig(ADC, ADC_Channel_5 , ADC_SampleTime_239_5Cycles);//���ò������ʺ�ͨ��
	
	//ADC_ChannelConfig(ADC, ADC_Channel_Vrefint , ADC_SampleTime_239_5Cycles);//���ò������ʺ�ͨ
	
	ADC_ITConfig(ADC, ADC_IT_EOC, ENABLE);
//	ADC_AnalogWatchdogThresholdsConfig(ADC, 1066, 800);//����ADCwatchdog�ߵͷ�ֵ
//	ADC_AnalogWatchdogSingleChannelCmd(ADC, ENABLE);//����ADCwatchdog
//	ADC_AnalogWatchdogSingleChannelConfig(ADC, ADC_AnalogWatchdog_Channel_8);//ѡ��ADCwatchdog_Channel8
//	
//	/* Enable AWD interrupt */
//  ADC_ITConfig(ADC, ADC_IT_AWD, ENABLE);//ʹ���ж�
//  
//  /* Configure and enable ADC1 interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = ADC1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
	//ADC_GetCalibrationFactor(ADC);

  /* Enable ADC1 */
  ADC_Cmd(ADC, ENABLE);

	while(!ADC_GetFlagStatus(ADC, ADC_FLAG_ADRDY)); 
	ADC_StartOfConversion(ADC);
}

void ADC1_IRQHandler(void)
{
		unsigned char i;
    if (ADC_GetFlagStatus(ADC,ADC_FLAG_AWD) != RESET)
    {
        ADC_ClearFlag(ADC,ADC_FLAG_AWD);
    }
		if (ADC_GetITStatus(ADC,ADC_IT_EOC)==SET) 
		{
			ADC_ClearITPendingBit(ADC,ADC_IT_EOC);
			adc_temp=ADC_GetConversionValue(ADC);
			if(real_temp==0)
				real_temp=adc_temp;
			if(adc_debouce_cnt<256)
			{
				adc_sum+=adc_temp;
				adc_debouce_cnt++;
			}
			else 
			{				
				adc_result[adc_array_cnt]=(unsigned int)(adc_sum>>8);
				if(bStartCalADC==0&&adc_array_cnt==0)
				{	
					for (i =0;i<10;i++)
						adc_result[i]=adc_result[adc_array_cnt];
				}	
				if (adc_array_cnt<9)
					adc_array_cnt++;
				else 
				{
					adc_array_cnt=0;
					bStartCalADC=1;
				}				
				real_temp=GetADCResult((unsigned int *) &adc_result[0]);					
				adc_debouce_cnt=0;
				adc_sum=0;
			}			
		}
		
}
void AHD_Pro(void)
{
	 if(CheckAHD&&bPlugNTC==0)
	 {			
		//  GPIO_SetBits(GPIOD,GPIO_Pin_7);
		  if(bPlugAHD)
				BSP_UART_SendString(UART2,"AHD\r\n");
			else if(bPlugSHD)
				BSP_UART_SendString(UART2,"SHD\r\n");
			else
			{
				 BSP_UART_SendString(UART2,"DEV\r\n");	
			}						
		//	GPIO_ResetBits(GPIOD,GPIO_Pin_7);
		  CheckAHD=0;
		//	BSP_UART_Config(COM2, 2400);
	 }
}
void uart_pro(void)
{
	unsigned char i=0,crc=0x87;
	if(uart1_rx_complete)
	{
		if(strstr((const char *)uart1_rx_buf,"AT+")!=NULL)
		{
			 if(strstr((const char *)uart1_rx_buf,"DEV=?")!=NULL)
			 {
				 BSP_UART_SendString(UART1,"Air780E!\r\n");
			 }
			 else if(strstr((const char *)uart1_rx_buf,"CHIPID")!=NULL)
			 {
					//SEND password  , seed +CHIPID =password,
				// GET CHIPID FOR authorizing, server will send seed for paasword
			 }
			 else if(strstr((const char *)uart1_rx_buf,"SEED")!=NULL)
				{
						// SEED = CHIPID + SECRETKEY
					 //SEND password  , seed +CHIPID =password,
					 // GET CHIPID FOR authorizing, server will send seed for paasword
					 //printf("\r\nAir780E!\r\n");
				}
				else if(strstr((const char *)uart1_rx_buf,"Sensor")!=NULL)
				{
//						GPIO_SetBits(GPIOD,GPIO_Pin_7);
						BSP_UART_SendString(UART2,"DEV\r\n");
//						GPIO_ResetBits(GPIOD,GPIO_Pin_7);
				}
		}				
		uart1_rx_complete=0;
	}

	if(uart2_rx_complete)
	{
		if(strstr((const char *)uart2_rx_buf,"AHSensor")!=NULL)
		{
			 //printf("AHSensor plug!\r\n");
//			GPIO_SetBits(GPIOD,GPIO_Pin_7);
			BSP_UART_SendString(UART2,"AHD\r\n");
//			GPIO_ResetBits(GPIOD,GPIO_Pin_7);
			bPlugAHD=1;
			bHumitySet=1;
			bHumityWDTCnt=0;
		//	BSP_UART_Config(COM2, 2400);
		}
		else if(strstr((const char *)uart2_rx_buf,"SHSensor")!=NULL)
		{
			 //printf("AHSensor plug!\r\n");
//			GPIO_SetBits(GPIOD,GPIO_Pin_7);
			BSP_UART_SendString(UART2,"SHD\r\n");
//			GPIO_ResetBits(GPIOD,GPIO_Pin_7);
			bPlugSHD=1;
			bHumitySet=1;
		}
		if((uart2_rx_buf[0]==0xaa)&&(uart2_rx_buf[1]==0xdd))//&&(uart2_rx_buf[4])==(0x87+uart2_rx_buf[2]+uart2_rx_buf[3]))
		{
				crc+=uart2_rx_buf[2];crc+=uart2_rx_buf[3];crc+=uart2_rx_buf[4];
				if((uart2_rx_buf[5])==crc)
			  {
					if(uart2_rx_buf[4]==0xA1)
					{
						HumityInt=uart2_rx_buf[2];
						HumityFrag=uart2_rx_buf[3];		
						bHumityWDTCnt=0;
						bPlugAHD=1;bHumitySet=1;
					}
					else if(uart2_rx_buf[4]==0xA2)
					{
						HumityInt=uart2_rx_buf[2];
						HumityFrag=uart2_rx_buf[3];		
						bHumityWDTCnt=0;
						bPlugSHD=1;bHumitySet=1;
					}
					
				//	printf("ʪ��:%d.%dRH\r\n",HumityInt,HumityFrag);
				}
				else
				{
					printf("CRC wrong!\r\n");
				}
		}
		for(i=0;i<8;i++)
		{
//			BSP_UART_SendByte(UART1,uart2_rx_buf[i]);
			uart2_rx_buf[i]=0;
		}
		uart2_rx_complete=0;		
	}	
}


void SysTick_Handler(void)//1ms
{
	sys_tick++;
	bHumityWDTCnt++;
	if(bHumityWDTCnt>1200)
	{
		bPlugSHD=0;
		bPlugAHD=0;
	}
	if ((sys_tick%500)==0)
	{
		toggle_temp_display^=0x01;
		bUpdateData=1;
		if(bResetTimer&&(sSysParams.SysSetting&ENABLE_BEEP)&&BeepCnt)
		{
				BeepTimeTick=BEEP_TIMEOUT_CNT;
				BeepCnt--;		
		}
	}
	if (BeepTimeTick)
	{
		BeepTimeTick--;		
	}
	
	if (sys_tick%1000==0)//1sec
	{
		if(SensorType==0&&(sSysParams.SettingMode==NOMAL_MODE))
		{
			BeepTimeTick=BEEP_TIMEOUT_CNT;
		}
		if(sSysParams.SysSetting&LOCK_KEY_SETTING)
		{
			if(lock_key_timecnt)
			{
				lock_key_timecnt--;
				if(lock_key_timecnt==0)
				{			 
					 lock_key=1;
				}
			}
		}
		else
			lock_key=0;
		if(icon_timecnt)
		{
			lock_key_timecnt=LOCK_TIMEOUT_CNT;
			icon_timecnt--;
			if(icon_timecnt==0)
			{
				bSaveParams=1;
			}
		}
		else
		{
			icon_index=0;
			if(CalTempMode)
			{
			//	sSysParams.params[0]=params_tmp;
				CalTempMode=0;	
			}				
		}
		if(lock_key_display_time)
		{
			lock_key_display_time--;
//			if(lock_key_display_time==0)
//			{
//				
//			}
		}
		EnableRelay=1;
		if (sys_sec<60)
		{
			sys_sec++;
			if(sys_sec>3) bResetParams=0;
		}
		else 
		{		
			bUpdateData=1;
			sys_sec=0;
			if(bStartRunSys)
			{
				if ((runing_time>0)&&bResetTimer==0)
				{
					runing_time-=1;
					sSysParams.params[0]=runing_time;
					if (runing_time<=0)
					{	
						bResetTimer=1;
						bSaveParams=1;
						BeepCnt=5;
						if(sSysParams.SettingMode==F2_MODE)
						{
							CtrlByte |=CTRL_HEAT_MASK;
							sSysParams.params[0]=sSysParams.TurnOnTime;
							runing_time=sSysParams.TurnOnTime;
						}
						else if(sSysParams.SettingMode==F3_MODE)
						{
							CtrlByte &=~CTRL_HEAT_MASK;
							sSysParams.params[0]=sSysParams.TurnOffTime;
							runing_time=sSysParams.TurnOffTime;
						}
					}			
				}
				if(sSysParams.SettingMode==F1_MODE)
				{
					if (CtrlByte&CTRL_HEAT_MASK)
					{
						if (sSysParams.params[0]>1)
						{
							sSysParams.params[0]--;
						}
						else 
						{
							sSysParams.params[0]=sSysParams.StartTime;
							Toggle_Heat_Ctrl();
			
						}
						
					}
					else 
					{
						if (sSysParams.params[1]>1)
						{
							sSysParams.params[1]--;
						}
						else 
						{
							sSysParams.params[1]=sSysParams.StopTime;
							Toggle_Heat_Ctrl();
						}
					}
				}
			
				}
		}
	}	
	key_pro();
	if(bStartRunSys)
		SysCtrl();
//	else
//		CtrlByte &=~CTRL_HEAT_MASK;
}

void SysCtrl(void)
{
	if (CalTempMode)
	{
	//	CtrlByte &=~CTRL_HEAT_MASK;
	}
	else if (sSysParams.SettingMode==NOMAL_MODE)
	{
		if (sSysParams.StopTemp==sSysParams.StartTemp||(current_temp==CURRENT_TEMP_NO_SENSOR))
		{			
			CtrlByte &=~CTRL_HEAT_MASK;
		}
		else if (sSysParams.StopTemp<sSysParams.StartTemp)//cool
		{
			if ((current_temp>=sSysParams.StartTemp)&&EnableRelay)
			{
				CtrlByte |= CTRL_HEAT_MASK;
			}
			else if(current_temp<=(sSysParams.StopTemp))
			{
				CtrlByte &=~CTRL_HEAT_MASK;
			}				
		}
		else //hot
		{
			if (current_temp>=sSysParams.StopTemp)
			{
				 CtrlByte &=~CTRL_HEAT_MASK;
			}
			else if((current_temp<=sSysParams.StartTemp)&&EnableRelay)			
			{
					CtrlByte |= CTRL_HEAT_MASK;	
			}				
		}
	}
}
void update_lcd(void)
{
	unsigned char i;
	if (bUpdateData)
	{	
		if(lock_key_display_time)
		{
			 password[lock_key_index]=(char)sSysParams.params[2];
			 dig_data[1]=num_table[password[0]];
			 dig_data[2]=num_table[password[1]];				
		}
		else if (CalTempMode)
		{
			lock_key_timecnt=LOCK_TIMEOUT_CNT;
			dig_data[9]|=CAL_ICON;
			if(icon_index==1)
				disdata_conveter(dig_data,sSysParams.params[2]);		
			else 
			{
				if(icon_index==2)
					dig_data[0]=num_table[11];//B
				else if(icon_index==3)
					dig_data[0]=num_table[20];//P
				else if(icon_index==4)
					dig_data[0]=num_table[18];//L
					
				dig_data[1]=num_table[17];//-
				if(sSysParams.params[2]) //
					dig_data[2]=num_table[1];//1
				else
					dig_data[2]=num_table[0];//0
			}
		}
		else if (sSysParams.SettingMode==NOMAL_MODE)
		{
			dig_data[9]|=REALTEMP_ICON;
			dig_data[10]|=START_ICON|START_TEMP_ICON|STOP_ICON|STOP_TEMP_ICON;
			if(bStartRunSys)
			{
				if(CtrlByte&CTRL_HEAT_MASK)
				{
					dig_data[9]|=TIMING_ON_ICON;
				}
				else
					dig_data[9]|=TIMING_OFF_ICON;
			}
			if(bPlugAHD||bPlugSHD)
			{
				//	HumidityFunc();
				TempInt=HumityInt+40;
				TempFrag=HumityFrag;
				SensorType=2;
			}
			else
			{	
				temp_func();	
			}
			SensorValDis();	
			disdata_conveter(&dig_data[STARTTEMP_INDEX],sSysParams.StartTemp);
			disdata_conveter(&dig_data[STOPTEMP_INDEX],sSysParams.StopTemp);
					
		}
		else if(sSysParams.SettingMode==F1_MODE)
		{
			dig_data[9]|=CYCLE_RUNNING_ICON|TIMING_ON_ICON|TIMING_OFF_ICON;
			if(bStartRunSys)
			{
				if (CtrlByte&CTRL_HEAT_MASK)
					dig_data[9]&=~TIMING_OFF_ICON;
				else
					dig_data[9]&=~TIMING_ON_ICON;
			}
			dig_data[10]|=STOP_ICON|STOP_TIME_ICON|STOP_MIN_ICON|START_ICON|START_TIME_ICON|START_MIN_ICON;
			dig_data[0]=num_table[15];//F
			dig_data[1]=num_table[0];//0
			dig_data[2]=num_table[1];//1
			disdata_conveter(&dig_data[STARTTEMP_INDEX],sSysParams.params[0]);
			disdata_conveter(&dig_data[STOPTEMP_INDEX],sSysParams.params[1]);
		}
		else
		{
			if(sSysParams.SettingMode==F2_MODE)//TIME ON
			{
				dig_data[0]=num_table[15];//F
				dig_data[1]=num_table[0];//0
				dig_data[2]=num_table[2];//2
				dig_data[9]|=TIMING_ICON|TIMING_ON_ICON;	
			//	sSysParams.params[0]=sSysParams.TurnOnTime;				
			}
			else if(sSysParams.SettingMode==F3_MODE)//TIME OFF
			{
				dig_data[9]|=TIMING_ICON|TIMING_OFF_ICON;		
				dig_data[0]=num_table[15];//F
				dig_data[1]=num_table[0];//0
				dig_data[2]=num_table[3];//3
			//	sSysParams.params[0]=sSysParams.TurnOffTime;		
			}
			if((sSysParams.params[0]<1000)||bResetTimer)
			{
				dig_data[10]|=STOP_TIME_ICON|STOP_MIN_ICON;		
				if(bResetTimer)
					disdata_conveter(&dig_data[STOPTEMP_INDEX],0);
				else
					disdata_conveter(&dig_data[STOPTEMP_INDEX],sSysParams.params[0]);		
				
			}
			else
			{
					dig_data[10]|=START_TIME_ICON|START_MIN_ICON;
					disdata_conveter(&dig_data[STARTTEMP_INDEX],sSysParams.params[0]/1000);
					disdata_conveter(&dig_data[STOPTEMP_INDEX],sSysParams.params[0]%1000);
			}
					
		}
		
		if(bStartRunSys)
				dig_data[9]|=RUNNING_ICON;
		else
				dig_data[9]&=~RUNNING_ICON;
		for (i=0;i<11;i++)
		{
			display_data[i]=dig_data[i];
			dig_data[i]=0;
		}
		
		if(toggle_temp_display)
		{
			if (bToggleDisplay&&(sSysParams.SettingMode==NOMAL_MODE))
			{
				display_data[0]=0;// 
				display_data[1]=0;// 
				display_data[2]=0;// 			
			}
			if((icon_index&&(key==0))||bResetParams)
			{
//				if(sSysParams.SettingMode==CAL_MODE)
//				{
//						if(icon_index==1)
//						{
//							display_data[0]=0;// 
//							display_data[1]=0;// 
//							display_data[2]=0;// 
//						}
//				}
//				else
//				{
					if(icon_index==1||(sSysParams.SettingMode>F1_MODE)||bResetParams)
					{
						display_data[3]=0;// 
						display_data[4]=0;// 
						display_data[5]=0;// 	
					}
					if(icon_index==2||(sSysParams.SettingMode>F1_MODE)||bResetParams)
					{
						display_data[6]=0;// 
						display_data[7]=0;// 
						display_data[8]=0;// 	
					}
			//	}
			}
			if(bStartRunSys)
			{
				  display_data[9]&=~RUNNING_ICON;
				//if(sSysParams.SettingMode==F1_MODE)
				//{
					if (CtrlByte&CTRL_HEAT_MASK)
					{
						if(sSysParams.SettingMode==F1_MODE)
						{
							display_data[10]&=~START_ICON;
						}
						else if(sSysParams.SettingMode==NOMAL_MODE)
						{
							display_data[9]&=~TIMING_ON_ICON;
						}
					}
					else
					{
						if(sSysParams.SettingMode==F1_MODE)
						{
							display_data[10]&=~STOP_ICON;
						}
						else if(sSysParams.SettingMode==NOMAL_MODE)
						{
							display_data[9]&=~TIMING_OFF_ICON;		
						}
					}
				//}			
			}
			if(bResetTimer&&(sSysParams.SettingMode>F1_MODE))
			{
				display_data[8]=0;// 
			}
			if(lock_key_display_time)
			{
				display_data[lock_key_index+1]=0;			
			}		
		}
		lcd_display();
		bUpdateData=0;
	}	
}
void temp_func(void)
{
//	real_temp=4000;
	if (real_temp>4050)
	{
		bStartCalADC=0;
		bPlugNTC=0;
		SensorType=0;
		TempInt=0;
	}
	else 
	{
		bPlugNTC=1;
		SensorType=1;
		if (real_temp>NTC_ADArray[0])
			TempInt=0;
		else if(real_temp<NTC_ADArray[NTC_ARRAY_CNT-1])
			TempInt=NTC_ARRAY_CNT;
		else
		{
			TempInt=NTCADBinarySearch(real_temp);
			TempFrag=((NTC_ADArray[TempInt]-real_temp)*10)/(NTC_ADArray[TempInt]-NTC_ADArray[TempInt+1]);	
		}	
	}		
}
void SensorValDis(void)
{	
	int temp_tmp=0;//caltemp_tmp=0;
	//
	temp_tmp=(int)TempInt*10+TempFrag;
	//caltemp_tmp=(int)sSysParams.CalTemp-99;
	temp_tmp+=sSysParams.CalTemp;
	if (temp_tmp<200)
	{
		//temp_tmp=200;
		bPlugNTC=0;
	}
	else if (temp_tmp>1600)
	{
		//temp_tmp=1600;
		bPlugNTC=0;
	}
	TempInt=(unsigned char)((unsigned int)temp_tmp/10);
	TempFrag=(unsigned char)((unsigned int)temp_tmp%10);
	if (bPlugNTC||bPlugAHD||bPlugSHD)
	{		
		bToggleDisplay=0;	
		temp_tmp-=400;//ZERO_TEMP
		current_temp=temp_tmp;
		disdata_conveter(dig_data,temp_tmp);
		if(bPlugNTC)
		{
			if(temp_tmp>=900)
			{
				bToggleDisplay=1;	
				if ((sys_tick%400)==0)
				{
					BeepTimeTick=BEEP_TIMEOUT_CNT;
				}
			}
			else if(temp_tmp<=-200)
			{
				 bToggleDisplay=1;	
			}
		}
	}	
	else
	{
		bToggleDisplay=1;
		dig_data[0]=0;// 
		dig_data[1]=num_table[14];// E
		if(temp_tmp>1600)
			dig_data[2]=num_table[1];// 1		
		else
			dig_data[2]=num_table[2];// 2	
		bStartRunSys=0;	
		current_temp=CURRENT_TEMP_NO_SENSOR;
		
	}

}

void disdata_conveter(unsigned char *disbuf,int data)
{
		if (CalTempMode||sSysParams.SettingMode==NOMAL_MODE)
		{				
				if(data>=1000&&data<10000)
				{
					*(disbuf+0)= num_table[(data/1000)];	
					*(disbuf+1)= num_table[(data/100)%10];	
					*(disbuf+2)= num_table[(data/10)%10];	
				}
				else if(data>=100&&(data<1000))
				{
					*(disbuf+0)= num_table[(data/100)];	
					*(disbuf+1)= num_table[(data/10)%10]|0x80;	
					*(disbuf+2)= num_table[data%10];
				}
				else if(data>=0&&(data<100))
				{
					*(disbuf+0)= 0;		
					*(disbuf+1)= num_table[(data/10)%10]|0x80;	
					*(disbuf+2)= num_table[data%10];					
				}				
				else if(data<0&&data>=-99)
				{
					 *(disbuf+0)= num_table[17];	//-1
					 data=0-data;
					*(disbuf+1)= num_table[(data/10)%10]|0x80;	
					*(disbuf+2)= num_table[data%10];
				}
				else if(data<-99&&data>=-999)
				{
					 *(disbuf+0)= num_table[17];	//-1
					 data=0-data;
					*(disbuf+1)= num_table[(data/100)%10];	
					*(disbuf+2)= num_table[(data/10)%10];
				}
		}
		else
		{
				if(data>=100&&(data<1000))
				{
					*(disbuf+0)= num_table[(data/100)];	
					*(disbuf+1)= num_table[(data/10)%10];	
				}
				else if(data>=10&&(data<100))
				{
					*(disbuf+1)= num_table[(data/10)%10];					
				}
				*(disbuf+2)= num_table[data%10];
		}
}

void key_pro(void)
{
	key_scan();
	//setting
	if (key&0x04) //mode
	{	
		key_pressed_cnt[3]++;
		if(key_pressed_cnt[3]>=KEY_LONG_PRESSED_CNT&&((key_pressed_cnt[3]%KEY_AUTO_INTERVALCNT)==0))
		{
			//key_func(0x08);
			if (key_pressed_cnt[3]<=(KEY_LONG_PRESSED_CNT+KEY_AUTO_INTERVALCNT))
			{
				BeepTimeTick=BEEP_TIMEOUT_CNT;		
				bUpdateData=1;			
				sys_sec=0;
				if(lock_key)
				{
					if(lock_key_display_time)
					{
						BeepTimeTick=BEEP_TIMEOUT_CNT;
						lock_key_index+=1;
						if(lock_key_index>1)
						{
							lock_key_index=0;
						}
						lock_key_display_time=LOCK_DIS_TIMEOUT_CNT;	
						 if((password[0]==6)&&(password[1]==8))
						 {
							 lock_key_display_time=0;
							 lock_key=0;
							 password[0]=0;
							 password[1]=0;
							 lock_key_index=0;
						 }
						sSysParams.params[2]=password[lock_key_index];
					}
				}
				else
				{
						BeepTimeTick=BEEP_TIMEOUT_CNT;
						icon_index=0;			
						//SET START
						if(CalTempMode)
						{
							CalTempMode=0;
							//sSysParams.params[2]=params_tmp;
						}
						else
						{
							bStartRunSys^=0x1;
							bSaveParams=1;
							if(bResetTimer)
							{
								bResetTimer=0;
							}
							if(bStartRunSys)
							{
								if(sSysParams.SettingMode==F2_MODE)
								{								
									CtrlByte &=~CTRL_HEAT_MASK;			
								}
								else if(sSysParams.SettingMode==F3_MODE)
								{
									CtrlByte |=CTRL_HEAT_MASK;		
								}
							}
						}
					}
				
			}
		}
	}
	else 
	{
		if ((key_pressed_cnt[3]>KEY_DEBOUCE_MINCNT)&&(key_pressed_cnt[3]<KEY_DEBOUCE_MAXCNT)&&(EnableCalMode==0))
		{
			sys_sec=0;
			if(lock_key)
			{
				if(lock_key_display_time)
				{
					BeepTimeTick=BEEP_TIMEOUT_CNT;
					lock_key_index+=1;
					if(lock_key_index>1)
					{
						lock_key_index=0;
					}
					lock_key_display_time=LOCK_DIS_TIMEOUT_CNT;	
					 if((password[0]==6)&&(password[1]==8))
					 {
						 lock_key_display_time=0;
						 lock_key=0;
						 password[0]=0;
						 password[1]=0;
						 lock_key_index=0;
					 }
					sSysParams.params[2]=password[lock_key_index];
				}
			}
			else
			{
			if(bStartRunSys==1) return;
				
			BeepTimeTick=BEEP_TIMEOUT_CNT;
			sSysParams.SettingMode+=1;
			if (sSysParams.SettingMode>=5)
							sSysParams.SettingMode=1;
							
			runing_time=0;										
			bSaveParams=1;
			bResetTimer=0;			
			max_key_value=999;
			min_key_value=1;
			icon_index=0;			
						//SET START
			if(CalTempMode)
			{
				CalTempMode=0;
				//sSysParams.params[2]=params_tmp;
			}
			else if (sSysParams.SettingMode==NOMAL_MODE)
				{
					max_key_value=1200;
					min_key_value=-200;
					sSysParams.params[0]=sSysParams.StartTemp;
					sSysParams.params[1]=sSysParams.StopTemp;	
				}
				else if (sSysParams.SettingMode==F1_MODE)
				{
					max_key_value=999;
					min_key_value=1;
					sSysParams.params[0]=sSysParams.StartTime;
					sSysParams.params[1]=sSysParams.StopTime;					
					CtrlByte |= CTRL_HEAT_MASK;					
					
				}
				else if(sSysParams.SettingMode==F2_MODE)
				{
					sSysParams.params[0]=sSysParams.TurnOnTime;
					CtrlByte &=~CTRL_HEAT_MASK;
					runing_time=sSysParams.params[0];				
				}
				else if(sSysParams.SettingMode==F3_MODE)
				{
					sSysParams.params[0]=sSysParams.TurnOffTime;
					CtrlByte |= CTRL_HEAT_MASK;
					runing_time=sSysParams.params[0];
				}	
			}
			bUpdateData=1;
		}
		key_pressed_cnt[3]=0;
	}		
	
	if((bStartRunSys==1)&&(lock_key==0)&&(EnableCalMode==0)) return;
	
	//add 
	if (key&0x01)
	{	
		key_pressed_cnt[1]++;
		if(key_pressed_cnt[1]>=KEY_LONG_PRESSED_CNT&&((key_pressed_cnt[1]%KEY_AUTO_INTERVALCNT)==0))
		{	
			if(key_pressed_cnt[2]>=KEY_LONG_PRESSED_CNT&&(bStartRunSys==0))
			{
					//reinitsys
					SetSysDefaultParams();
					bResetParams=1;
					bUpdateData=1;
					bSaveParams=1;
					sys_sec=0;
			}
			else
				key_func(0x01);
			if (key_pressed_cnt[1]<=(KEY_LONG_PRESSED_CNT+KEY_AUTO_INTERVALCNT))
			{
				BeepTimeTick=BEEP_TIMEOUT_CNT;
			}
		}
	}
	else 
	{
		if ((key_pressed_cnt[1]>KEY_DEBOUCE_MINCNT)&&(key_pressed_cnt[1]<KEY_DEBOUCE_MAXCNT))
		{
			key_func(0x01);
			BeepTimeTick=BEEP_TIMEOUT_CNT;
		}
		key_pressed_cnt[1]=0;
	}
	//dec
	if (key&0x02)
	{
		key_pressed_cnt[2]++;
		if(key_pressed_cnt[2]>=KEY_LONG_PRESSED_CNT&&((key_pressed_cnt[2]%KEY_AUTO_INTERVALCNT)==0))
		{
			if(key_pressed_cnt[1]>=KEY_LONG_PRESSED_CNT&&(bStartRunSys==0))
			{
					//reinitsys
					SetSysDefaultParams();
					bUpdateData=1;
					bSaveParams=1;
					bResetParams=1;
					sys_sec=0;
			}
			else
				key_func(0x02);
			if (key_pressed_cnt[2]<=(KEY_LONG_PRESSED_CNT+KEY_AUTO_INTERVALCNT))
			{
				BeepTimeTick=BEEP_TIMEOUT_CNT;
			}
		}
	}
	else 
	{
		if ((key_pressed_cnt[2]>KEY_DEBOUCE_MINCNT)&&(key_pressed_cnt[2]<KEY_DEBOUCE_MAXCNT))
		{
				key_func(0x02);
				BeepTimeTick=BEEP_TIMEOUT_CNT;
		}
		key_pressed_cnt[2]=0;
	}	
	if(key&&toggle_temp_display)
	{
		sys_tick=1;
		toggle_temp_display=0;
		bUpdateData=1;
	}
	if(lock_key) return ;
	if (key&0x08)//set
	{
		key_pressed_cnt[0]++;
		if(key_pressed_cnt[0]>=KEY_LONG_PRESSED_CNT&&((key_pressed_cnt[0]%KEY_AUTO_INTERVALCNT)==0))
		{		
			if ((key_pressed_cnt[0]<=(KEY_LONG_PRESSED_CNT+KEY_AUTO_INTERVALCNT))&&EnableCalMode)//only one enter
			{					
					bStartRunSys=0;
					EnableCalMode=0;
					BeepTimeTick=BEEP_TIMEOUT_CNT;	
					CalTempMode=1;;
					icon_index=1;
					icon_timecnt=INDEX_TIMEOUT_CNT;
					sys_sec=0;
					max_key_value=99;
					min_key_value=-99;
				//	params_tmp=sSysParams.params[0];
					sSysParams.params[2]=sSysParams.CalTemp;
								
			}
		}
		
	}
	else 
	{
		if ((key_pressed_cnt[0]>KEY_DEBOUCE_MINCNT)&&(key_pressed_cnt[0]<KEY_DEBOUCE_MAXCNT))
		{
				icon_timecnt=INDEX_TIMEOUT_CNT;
				BeepTimeTick=BEEP_TIMEOUT_CNT;
				icon_index+=1;
				if (CalTempMode)
				{
						if(icon_index>=5)
						{
							icon_index=1;
						}
				}
				else
				{
					if(sSysParams.SettingMode==NOMAL_MODE||sSysParams.SettingMode==F1_MODE)
					{
						if(icon_index>=3)
						{
							icon_index=1;
						//	sSysParams.SettingMode+=1;
						}
					}
					else
					{
							if(icon_index>=2)
							{
								icon_index=1;
							//	sSysParams.SettingMode+=1;
							}
					}
//					if (sSysParams.SettingMode>=5)
//							sSysParams.SettingMode=1;
				}
				sys_sec=0;								
				bSaveParams=1;
				bResetTimer=0;			
				if(CalTempMode)
				{
					max_key_value=1;
					min_key_value=0;
					if(icon_index==1)
					{
						max_key_value=99;
						min_key_value=-99;
						sSysParams.params[2]=sSysParams.CalTemp;
					}
					else if(icon_index==2)
					{
						if(sSysParams.SysSetting&ENABLE_BEEP)
							sSysParams.params[2]=1;
						else sSysParams.params[2]=0;
					}
					else if(icon_index==3)
					{
						if(sSysParams.SysSetting&SAVE_WORK_STA_SETTING)
							sSysParams.params[2]=1;
						else sSysParams.params[2]=0;
					}
					else if(icon_index==3)
					{
						if(sSysParams.SysSetting&LOCK_KEY_SETTING)
							sSysParams.params[2]=1;
						else sSysParams.params[2]=0;
					}
					
				}
				
				bUpdateData=1;				
		}	
		key_pressed_cnt[0]=0;
	}		


}
void key_func(unsigned char keycmd)
{
		unsigned icon_index_tmp;
		sys_sec=0;	
		icon_timecnt=INDEX_TIMEOUT_CNT;	
		if(icon_index||lock_key)
		{	
			bUpdateData=1;
			icon_index_tmp=icon_index-1;
			if(CalTempMode)
				icon_index_tmp=2;
			if(lock_key)
			{
				min_key_value=0;
				max_key_value=9;
			  icon_index_tmp=2;		
				if(lock_key_display_time==0)
				{
					lock_key_index=0;
					sSysParams.params[icon_index_tmp]=0;
					lock_key_display_time=LOCK_DIS_TIMEOUT_CNT;	
					return;
				}
				lock_key_display_time=LOCK_DIS_TIMEOUT_CNT;	
			}
			else
				lock_key_index=0;
			if (keycmd==0x01)
			{			
					if (sSysParams.params[icon_index_tmp]>min_key_value)
					{
						if ((sSysParams.params[icon_index_tmp]>1009&&(sSysParams.SettingMode==NOMAL_MODE))||
								(sSysParams.params[icon_index_tmp]<=-100&&(sSysParams.SettingMode==NOMAL_MODE)))
							sSysParams.params[icon_index_tmp]-=10;
						else
							sSysParams.params[icon_index_tmp]--;
						
					}
					else 
					{
						sSysParams.params[icon_index_tmp]=max_key_value;
					}
			}
			else if(keycmd==0x02)
			{
					if (sSysParams.params[icon_index_tmp]<max_key_value)
					{
						
						if( ((sSysParams.params[icon_index_tmp]<1191)&&(sSysParams.params[icon_index_tmp]>999)&&(sSysParams.SettingMode==NOMAL_MODE))||
								((sSysParams.params[icon_index_tmp]<-100)&&(sSysParams.params[icon_index_tmp]>=-200)&&(sSysParams.SettingMode==NOMAL_MODE)))
						{
							sSysParams.params[icon_index_tmp]+=10;
						}
						else
						sSysParams.params[icon_index_tmp]++;
					}
					else 
					{
						sSysParams.params[icon_index_tmp]=min_key_value;
					}
			}	
			if(CalTempMode)
			{
					if(icon_index==1)
						sSysParams.CalTemp=sSysParams.params[2];
					else if(icon_index==2)
					{
						if(sSysParams.params[2]==1)
							sSysParams.SysSetting |=ENABLE_BEEP;
						else
							sSysParams.SysSetting &=~ENABLE_BEEP;
					}
					else if(icon_index==3)
					{
						if(sSysParams.params[2]==1)
							sSysParams.SysSetting |=SAVE_WORK_STA_SETTING;
						else
							sSysParams.SysSetting &=~SAVE_WORK_STA_SETTING;
					}
					else if(icon_index==4)
					{
						if(sSysParams.params[2]==1)
							sSysParams.SysSetting |=LOCK_KEY_SETTING;
						else
							sSysParams.SysSetting &=~LOCK_KEY_SETTING;
					}
			}
			else if(sSysParams.SettingMode==NOMAL_MODE)
			{
					sSysParams.StartTemp=sSysParams.params[0];
					sSysParams.StopTemp=sSysParams.params[1];	
			}
			else if(sSysParams.SettingMode==F1_MODE)
			{
				sSysParams.StartTime=sSysParams.params[0];
				sSysParams.StopTime=sSysParams.params[1];
				runing_time=0;
			}
			else if(sSysParams.SettingMode==F2_MODE)
			{
				sSysParams.TurnOnTime=sSysParams.params[0];
				runing_time=sSysParams.TurnOnTime;
			}
			else if(sSysParams.SettingMode==F3_MODE)
			{
				sSysParams.TurnOffTime=sSysParams.params[0];				
				runing_time=sSysParams.TurnOffTime;
			}
		}
		
}
void key_scan(void)
{
	if(GPIO_ReadInputDataBit(K1_Port,K1_MASK))
	{
		key_tmp&=~0x01;
	}
	else 
	{
		key_tmp|=0x01;
	}
	if(GPIO_ReadInputDataBit(K2_Port,K2_MASK))	
	{
		key_tmp&=~0x02;
	}
	else 
	{
		key_tmp|=0x02;
	}
	if(GPIO_ReadInputDataBit(K3_Port,K3_MASK))
	{
		key_tmp&=~0x04;
	}
	else 
	{
		key_tmp|=0x04;
	}
	if(GPIO_ReadInputDataBit(K4_Port,K4_MASK))
	{
		key_tmp&=~0x08;
	}
	else 
	{
		key_tmp|=0x08;
	}
	if (key_tmp!=key)
	{
		key_debouce++;
		if (key_debouce>KEY_DEBOUCE_MINCNT)
		{
			key=key_tmp;
			key_debouce=0;
			
		}
	}
	else 
	{
		key_debouce=0;
	}	
}

unsigned int NTCADBinarySearch(unsigned int CurrentAD)
{	
   unsigned int start=0; //???(??)
   unsigned int end = NTC_ARRAY_CNT; //???(??)
   unsigned int mid = 0;  //????(??)
   while(start<=end)
   {  	  
      mid=(start+end)>>1;//?? ???(??)			 
      if(CurrentAD==NTC_ADArray[mid]) return mid;;  //??AD????????? ????
      if((CurrentAD<NTC_ADArray[mid])&&(CurrentAD>NTC_ADArray[mid+1])) return mid; //?????

      if(CurrentAD>NTC_ADArray[mid])  //??AD????????? ???????????
		 end = mid-1;  //????????? ???????
      else if(CurrentAD<NTC_ADArray[mid])  //??AD????????? ???????????
		 start = mid+1;   //????????? ???????
   }
   return mid;//?????????
}
unsigned int GetADCResult(unsigned int *adc_data_ptr)
{
	unsigned int max_adc=0,min_adc=4096;
	unsigned int sum=0;
	unsigned char i;
	for(i=0;i<10;i++)
	{
		 if(*(adc_data_ptr+i)>max_adc)
		 {
				max_adc=*(adc_data_ptr+i);
		 }
		 if(*(adc_data_ptr+i)<min_adc)
		 {
				min_adc=*(adc_data_ptr+i);
		 }		
		 sum+= *(adc_data_ptr+i);
	}
	sum=sum-max_adc-min_adc;
	return (unsigned int)(sum>>3);
}

void delay_us(unsigned int time)
{    
   unsigned int i=0; 
	// GPIO_ResetBits(OneWirePort,OneWire_MASK);
	// OneWirePort->ODR &=~OneWire_MASK;
//	OneWirePort->BRR = OneWire_MASK;
   while(time)
   { 
			 for(i=0;i<3;i++)
			 {
				 GPIOB->BSRR =GPIO_Pin_7;//NO ATICON
			 }		 
			 time-=1;
   }	 
	//  OneWirePort->ODR |=OneWire_MASK;
//	OneWirePort->BSRR = OneWire_MASK;
}

void delay_ms(unsigned int time)
{    
//   unsigned int i=0;  
   while(time--)
   {
     delay_us(1000);  
   }
}

void beep(void)//2khz 200ms
{
	unsigned int i;
	if(BeepTimeTick)
	{
		SysTick->CTRL &=~SysTick_CTRL_ENABLE_Msk;
		ADC_ITConfig(ADC, ADC_IT_EOC, DISABLE);
		for(i=0;i<800;i++)
		{
			GPIO_Toggle(GPIOC,GPIO_Pin_3);	
			delay_us(256);//250us
		}
		SysTick->CTRL |=  SysTick_CTRL_ENABLE_Msk;
		ADC_ITConfig(ADC, ADC_IT_EOC, ENABLE);
		GPIO_ResetBits(GPIOC,GPIO_Pin_3);
		BeepTimeTick=0;
	}	
}
void SaveParams(void)
{	
		if (bSaveParams)
		{
			sSysParams.SysSetting =(sSysParams.SysSetting&~SYS_WORK_STA)|bStartRunSys;
			if(bResetTimer)
				sSysParams.SysSetting|=RESET_TIMER;
			else
				sSysParams.SysSetting&=~RESET_TIMER;
			Flash_Erase(FLASH_ADDRESS);
			Flash_Write(FLASH_ADDRESS,&sSysParams.pkt_id,sizeof(sSysParams));
			bSaveParams=0;
//			printf("save params!\r\n");
//		 	delay_ms(5000);
		}
}
void RestoreParams(void)
{
		unsigned char i;
		for(i=0;i<sizeof(SYS_PARAMS);i++)
		{
			 *(&sSysParams.pkt_id+i)= *(__IO uint8_t*)(FLASH_ADDRESS+i);
		}		
//		Flash_Erase(FLASH_ADDRESS);
////		printf("params id:%d",sSysParams.pkt_id);
//		printf("params set:%d",sSysParams.params_set);
//		printf("params mode:%d",sSysParams.SettingMode);		
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char* file , uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */	
       /* Infinite loop */
	printf("Wrong parameters value: file %s on line %d\r\n", file, line);
	while (1)
  {		
  }
}
#endif /* USE_FULL_ASSERT */


