.\objects\keil_startup_hk32f0301mxxc.o: ..\lib\CMSIS\HK32F0301MxxC\Source\ARM\KEIL_Startup_hk32f0301mxxc.s
